---
name: meeting-prep-generator
description: Generate pre-meeting briefs with relationship history, pending items, and talking points. Use when user asks to prep for a meeting or requests a meeting brief.
---

# Meeting Prep Generator

## Purpose
Before any meeting, automatically generate a comprehensive brief that reconstructs relationship context, surfaces pending commitments, and suggests strategic talking points.

## When to Use
- User says "prep for my meeting with [name]"
- User asks "brief me on [company/person]"
- User requests "what do I need to know before talking to [name]"
- User says "help me prepare for [meeting]"

## How This Works

You have access to:
1. **Past conversations** - Search through our conversation history for mentions of this person/company
2. **Google Calendar** - Find upcoming meetings and past meeting history
3. **Google Drive** - Search for documents related to this person/company
4. **Asana** - Look for tasks assigned to or related to this person/company

Use ALL of these sources to build a complete picture.

## Output Format

Generate a structured brief in this exact format:
```
# Pre-Meeting Brief: [Person Name / Company Name]

**Meeting Details:**
- Date & Time: [From calendar]
- Duration: [From calendar]
- Location/Link: [From calendar]
- Last interaction: [Date of last meeting/email if found]

---

## Relationship Context

**Who They Are:**
[Role, company, how you know them, 1-2 sentences]

**Relationship Stage:**
[New contact / Active partnership / Established relationship / Board member / Client / etc.]

**Communication Style:**
[Any notable preferences: formal/casual, email/calls, responsive/slow, cultural context]

---

## Recent History

**Last Discussed:** [Most recent conversation date]
[2-3 sentence summary of what you last talked about]

**Key Topics Over Time:**
- [Topic 1 with approximate date]
- [Topic 2 with approximate date]
- [Topic 3 with approximate date]

---

## Pending Commitments

**What You Owe Them:**
- [Commitment 1] - Status: [Pending/Overdue/Complete]
- [Commitment 2] - Status: [Pending/Overdue/Complete]

**What They Owe You:**
- [Commitment 1] - Status: [Pending/Overdue]
- [Commitment 2] - Status: [Pending/Overdue]

**Open Decisions:**
- [Decision point 1]
- [Decision point 2]

*If none found, write: "No outstanding commitments found in recent history."*

---

## Active Projects/Initiatives

[List any Asana projects, Drive documents, or ongoing work streams involving this person/company]

**Status:**
- [Project 1]: [Brief status]
- [Project 2]: [Brief status]

---

## Suggested Talking Points

**Must Address:**
1. [Critical item that needs resolution]
2. [Overdue commitment or decision]

**Should Discuss:**
1. [Strategic topic based on relationship context]
2. [Follow-up from last conversation]
3. [Opportunity or next step]

**Could Explore:**
1. [Optional topic if time permits]
2. [Relationship-building question]

---

## Watch Fors

**Sensitivities:**
[Any cultural, timing, or relationship dynamics to be aware of]

**Potential Blockers:**
[Anything that might prevent progress]

**Red Flags:**
[If this relationship has had issues, communication gaps, or concerns]

*If none, write: "No known sensitivities or concerns."*

---

## Quick Reference

**Key Documents:**
- [Document title with Drive link]
- [Document title with Drive link]

**Related Asana Tasks:**
- [Task title with link]
- [Task title with link]

**Recent Emails:**
[If you can search Gmail, include 1-2 most recent email subjects with dates]

---

## Prep Checklist

Before the meeting, make sure you:
- [ ] Review any documents they sent
- [ ] Check if you owe them any follow-ups
- [ ] Confirm you have their correct contact/meeting link
- [ ] [Any meeting-specific prep item based on context]
```

## Research Process

**Step 1: Identify the person/company**
- Extract name from user's request
- Search past conversations for any mention
- Look up in calendar for upcoming meetings

**Step 2: Gather relationship data**
Use `conversation_search` tool to find:
- Past discussions mentioning this person/company
- Commitments made
- Topics discussed
- Last interaction date

**Step 3: Search Google Drive**
Use `google_drive_search` tool to find:
- Documents mentioning this person/company
- Meeting notes
- Proposals, contracts, presentations

**Step 4: Check Google Calendar**
Use `list_gcal_events` tool to find:
- Upcoming meeting details
- Past meeting history
- Meeting frequency pattern

**Step 5: Search Asana**
Use `Asana:asana_typeahead_search` to find:
- Tasks assigned to this person
- Projects involving this company
- Pending action items

**Step 6: Synthesize everything**
Compile all findings into the structured brief format above.

## Important Rules

1. **Never fabricate information** - If you can't find something, say so
2. **Always search ALL available sources** - Don't skip Drive, Asana, or conversation history
3. **Flag gaps** - If key information is missing, note it with [INFORMATION UNAVAILABLE]
4. **Be strategic** - Talking points should be actionable, not generic
5. **Respect cultural context** - Adapt tone recommendations based on relationship
6. **Time-sensitive** - Flag if commitments are overdue or decisions are time-critical
7. **Never use em dashes** - Use commas, periods, or parentheses instead

## Handling Different Scenarios

**Scenario 1: First-time meeting (no history)**
```
## Relationship Context
**Who They Are:**
[Research based on any available context]

**This is a first meeting.**

**Recommended approach:**
[Suggest discovery questions, relationship-building focus]
```

**Scenario 2: Haven't talked in months**
```
## Recent History
**Last interaction:** [Date - X months ago]
**Conversation gap:** It's been [X] months since your last conversation.

**Reconnection approach:**
- Acknowledge the gap
- [Suggest reentry point based on past discussions]
```

**Scenario 3: Active partnership with lots of context**
```
[Include detailed history, multiple pending items, strategic next steps]
```

**Scenario 4: Unclear who the meeting is with**
If user just says "prep for my 3pm meeting":
- Check calendar for 3pm meeting
- Extract attendee names
- Generate brief for key attendees

## Language Handling

**Brazilian partners:** Note cultural context (more formal, relationship-oriented)
**US partners:** Note efficiency-focused communication style
**Asian partners:** Note hierarchy and formal communication preferences

## Quality Checklist

Before delivering the brief:
- [ ] Searched past conversations
- [ ] Checked Google Drive for documents
- [ ] Looked up calendar history
- [ ] Searched Asana for tasks/projects
- [ ] Identified pending commitments
- [ ] Suggested actionable talking points
- [ ] Flagged any time-sensitive items
- [ ] Included document/task links where relevant

## Example Trigger Phrases

User might say:
- "Prep me for my meeting with Marcio tomorrow"
- "I need a brief on InovaEduK before our call"
- "What do I need to know before talking to Scott at Avatar Partners?"
- "Brief me on the upcoming Thinkie session"
- "Help me prepare for the board meeting"

When you see any of these patterns, invoke this Skill.