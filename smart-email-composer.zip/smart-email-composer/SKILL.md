---
name: smart-email-composer
description: Draft emails with appropriate tone and context based on relationship type and situation. Use when user asks to write, draft, or compose an email.
---

# Smart Email Composer

## Purpose

Generate context-aware emails that match Chandler's voice, adapt to relationship dynamics, and pull relevant background from past conversations, Drive docs, and Asana. Eliminates time spent reconstructing context and crafting appropriate tone for each recipient.

## When to Use

- User says "write an email to [person]"
- User asks "draft a follow-up to [person] about [topic]"
- User requests "compose an introduction between [person A] and [person B]"
- User says "I need to email [person] about [situation]"
- User asks for "check-in email" or "status update email"

## Core Workflow

When user requests an email:

1. **Identify the recipient** - Extract name/company from request
2. **Gather context** - Search past conversations, Drive docs, Asana for relevant information
3. **Determine relationship type** - Assess formality, cultural context, communication style
4. **Select email type** - Follow-up, introduction, status update, proposal, check-in, board communication
5. **Draft email** - Write in Chandler's voice with appropriate tone
6. **Offer variations** - Provide options if tone/length could vary

## Context Research Protocol

Execute these steps for every email request:

**Step 1: Identify recipient**
- Extract name/company from user's request
- Confirm if there's ambiguity

**Step 2: Search past conversations**
Use `conversation_search` to find:
- Previous discussions with this person
- Topics discussed
- Commitments made
- Relationship tone/style

**Step 3: Check calendar**
Use `list_gcal_events` to find:
- Recent meetings with this person
- Upcoming scheduled meetings
- Meeting frequency pattern

**Step 4: Search Drive (if relevant to topic)**
Use `google_drive_search` to find related documents, proposals, or meeting notes

**Step 5: Check Asana (if project-related)**
Use Asana tools to find related tasks, projects, status updates, or pending action items

**Step 6: Search Gmail (if checking recent communication)**
Use `search_gmail_messages` to find recent exchanges and communication patterns

## Email Templates

For complete template library with detailed examples and variations, see [REFERENCE.md](REFERENCE.md).

### Quick Reference

**Follow-Up After Meeting:**
```
Subject: [Specific topic] - Next Steps

Hi [First Name],

[One sentence acknowledging the meeting]

[2-3 sentences covering key takeaways]

**Next steps:**
- [Chandler's action with timeframe]
- [Their action with timeframe]

[Forward-looking sentence]

[Sign-off]
Chandler
```

**Partnership Check-In:**
```
Subject: [Partnership/Project Name] - Quick Check-In

Hi [First Name],

[Personal or relationship acknowledgment]

[2-3 sentences on status/progress/question]

[If action needed] Would be helpful to [specific request] by [timeframe].

[Relationship-building close]

[Sign-off]
Chandler
```

**Introduction (Double Opt-In):**
```
To: [Person A]
Subject: Introduction to [Person B]

Hi [First Name A],

I'd like to introduce you to [Full Name B], [their role/expertise].

[2-3 sentences on Person B's background and why connection makes sense]

If you're interested in connecting, let me know and I'll make the introduction.

Best,
Chandler
```

**Status Update:**
```
Subject: [Project Name] Update - [Date]

Hi [First Name],

Quick update on [project]:

**Progress:** [Accomplishments]
**Current Focus:** [What's happening now]
**Next Steps:** [Upcoming milestones]

[Timeline reference]

[Sign-off]
Chandler
```

**Proposal/Partnership Pitch:**
```
Subject: [Clear Value Proposition]

Hi [First Name],

[Context setter]

[2-3 sentences on opportunity]

**What this looks like:**
- [Concrete elements]

**Next step:** [Clear call to action]

[Sign-off]
Chandler
```

**Board/Governance Communication:**
```
Subject: [Specific Topic] - [Board/Organization Name]

Dear [Full Name],

[Formal opening and context]

[Details in clear sections]

**Action Required:** [If applicable]
**Timeline:** [Key dates]

Best regards,
Chandler Lewis
```

For detailed templates with cultural adaptations and extensive examples, consult [REFERENCE.md](REFERENCE.md).

## Relationship Type Detection

**Brazilian Partners:**
- Indicators: Portuguese names, Brazil location, past Portuguese mentions
- Tone: Warmer, relationship-first, acknowledge personal elements

**US Corporate/VC Partners:**
- Indicators: US-based companies, business formal patterns
- Tone: Direct, efficiency-focused, action-oriented

**Asian Partners:**
- Indicators: China, Singapore, Japan, South Korea locations
- Tone: More formal, hierarchy-conscious, relationship-building

**Board Members/Governance:**
- Indicators: Title includes "Board" or formal governance role
- Tone: Formal, documented, clear accountability

**Established Relationships:**
- Indicators: Frequent past conversations, casual language in history
- Tone: First-name basis, conversational, less formal

**New Contacts:**
- Indicators: No or limited conversation history
- Tone: Professional, slightly more formal, relationship-building

For extended cultural communication guidelines, see [REFERENCE.md](REFERENCE.md).

## Language Handling

**When to offer Portuguese version:**
- Recipient is Brazilian
- Past conversations indicate Portuguese preference
- Cultural context suggests relationship-oriented approach

**Format:**
```
[English version of email]

---

*(Versão em português disponível se preferir)*
```

Then provide Portuguese translation that maintains same structure, appropriate formality level, and cultural adaptation (not literal translation).

## Chandler's Voice Guidelines

**Core Principles:**
- Brevity with depth (no fluff, but substance)
- Purpose-driven (connect to why, not just what)
- Strategic alignment (how this fits bigger picture)
- Authentic and relational (professional but human)
- Time is precious (make it easy to act on)

**Critical Rules:**
- NEVER use em dashes (use commas, periods, parentheses)
- No overly apologetic language
- No excessive hedging ("I think maybe possibly")
- No generic platitudes
- Avoid unnecessary formality with established relationships

**Always Include:**
- Specific next steps with owners
- Clear timelines when relevant
- Acknowledgment of recipient's context
- Forward momentum

For voice principles in action with examples, see [REFERENCE.md](REFERENCE.md).

## Output Format

**Standard delivery:**
```
**Email Draft:**

Subject: [Subject line]

[Email body]

---

**Context used:**
- [What sources you pulled from]
- [Any assumptions made]

**Alternative versions available:**
- More formal/casual
- Portuguese translation (if Brazilian recipient)
- Longer/shorter

Would you like any adjustments?
```

## Quality Checklist

Before delivering email:
- [ ] Researched recipient in past conversations
- [ ] Checked calendar for recent meetings
- [ ] Searched relevant Drive docs or Asana tasks
- [ ] Determined relationship type and appropriate tone
- [ ] Matched Chandler's voice and principles
- [ ] Included specific next steps if needed
- [ ] No em dashes anywhere
- [ ] Subject line is clear and specific
- [ ] Offered Portuguese version if Brazilian recipient

## Important Rules

1. **Always research before writing** - Don't guess at context
2. **Match the relationship** - Formal/casual based on history
3. **Be specific** - Concrete next steps, real dates
4. **Never fabricate** - If you don't have information, note [NEEDS CONTEXT]
5. **Cultural awareness** - Adapt tone for Brazilian/US/Asian contexts
6. **No em dashes** - Ever
7. **Offer options** - When tone could vary, show alternatives
8. **Subject lines matter** - Clear, specific, action-oriented