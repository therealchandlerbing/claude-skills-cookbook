# Smart Email Composer Reference Guide

This reference guide contains detailed email templates, cultural communication guidelines, voice examples, and industry-specific vocabulary. Use this when crafting emails to ensure appropriate tone, structure, and cultural sensitivity.

## Complete Email Template Library

### Template 1: Follow-Up After Meeting

**When to use:** User mentions "follow-up" and references a recent meeting

**Standard Structure:**
```
Subject: [Specific topic] - Next Steps

Hi [First Name],

[One sentence acknowledging the meeting/call]

[2-3 sentences covering key takeaways or decisions made]

**Next steps:**
- [Chandler's action with timeframe]
- [Their action with timeframe]
- [Any coordination needed]

[One forward-looking sentence about impact or next milestone]

[Appropriate sign-off]
Chandler
```

**Example - Brazilian Partner Context:**
```
Subject: InovaEduK Partnership - Next Steps from Today's Call

Hi Marcio,

Great connecting today. Your vision for expanding digital literacy in underserved communities aligns perfectly with what we're building at 360.

From our discussion, the three priority areas are: (1) establishing pilot schools in São Paulo, (2) developing teacher training modules, and (3) creating metrics for impact measurement.

**Next steps:**
- Chandler: Share curriculum framework and timeline proposal by Friday
- Marcio: Connect us with pilot school coordinator by next week
- Both: Schedule follow-up for early November to review pilot plan

Looking forward to bringing this to life together.

Abraço,
Chandler

---

*(Versão em português disponível se preferir)*
```

**Example - US VC Partner Context:**
```
Subject: Avatar Partners Portfolio Updates - Action Items

Hi Scott,

Appreciate the time today to review Q4 performance across the portfolio.

Key takeaways: Smart Factory decision moved to December board meeting, InovaEduK pilot launch confirmed for January, and we're tracking three new BD opportunities in manufacturing.

**Next steps:**
- Chandler: Send updated financial projections by Wednesday
- Scott: Connect with CFO candidates for Smart Factory by end of month
- Both: Sync again before December board meeting

These moves position us well for Q1 acceleration.

Best,
Chandler
```

**Tone Variations:**
- **Brazilian partners**: Warmer opening, relationship acknowledgment, use "Abraço" or "Warmly"
- **US partners**: More direct, focus on decisions and actions, use "Best" or "Thanks"
- **Established relationships**: Casual, conversational, first-name familiarity
- **New relationships**: Professional but warm, full signature

---

### Template 2: Partnership Check-In

**When to use:** User wants to check in on partnership status or maintain relationship

**Standard Structure:**
```
Subject: [Partnership/Project Name] - Quick Check-In

Hi [First Name],

[Personal or relationship acknowledgment - reference something recent if available]

I wanted to touch base on [specific project/partnership]. [Brief context sentence]

[2-3 sentences on status, progress, or question]

[If action needed] Would be helpful to [specific request] by [timeframe].

[Relationship-building close that maintains momentum]

[Sign-off]
Chandler
```

**Example - Brazilian Manufacturing Partner:**
```
Subject: NWK Global Partnership - Q4 Check-In

Hi Felipe,

Hope things are going well in São Paulo. I saw the news about the automation contract win - congratulations on that milestone.

Wanted to touch base on our Smart Factory partnership. We've completed the initial assessment phase and are ready to move into pilot design. Based on our last conversation, timing still looks good for a January launch.

A few questions for you:
- Has the leadership team confirmed budget allocation for Q1?
- Can we schedule a site visit in early December to finalize equipment specs?
- Should we involve your operations lead in the next planning session?

Would be helpful to get these aligned by mid-November so we can move smoothly into implementation.

Looking forward to making this a showcase project together.

Abraço,
Chandler
```

**Example - US Corporate Partner:**
```
Subject: Smart Factory Project - Status and Timeline

Hi Michelle,

Quick check-in on the Smart Factory implementation timeline.

We've hit all Phase 1 milestones and are on track for January deployment. Current focus is finalizing equipment integration specs and training protocols.

Need confirmation on:
- Site access dates for December installation
- Final approval on training schedule
- Point person for ongoing operations coordination

Can we sync next week to lock these in?

Thanks,
Chandler
```

---

### Template 3: Introduction/Connector Email

**When to use:** User wants to connect two people in their network

**Double Opt-In Format (always use this approach):**

**Step 1 - Ask Permission:**
```
To: [Person A]
Subject: Introduction to [Person B]

Hi [First Name A],

I'd like to introduce you to [Full Name B], [their role/expertise].

[2-3 sentences explaining Person B's relevant background and why the connection makes sense]

[Specific collaboration opportunity or mutual benefit]

If you're interested in connecting, let me know and I'll make the introduction.

Best,
Chandler
```

**Step 2 - Make Introduction (only if Person A confirms interest):**
```
To: [Person A], [Person B]
Subject: [Person A Name] <> [Person B Name]

[Person A], meet [Person B].
[Person B], meet [Person A].

**[Person A]:** [Role, relevant expertise, why they're impressive - 2 sentences]

**[Person B]:** [Role, relevant expertise, why they're impressive - 2 sentences]

**Why this connection:**
[1-2 sentences on mutual benefit, collaboration opportunity, or shared interest]

I'll let you both take it from here. [Person A/Person B - suggest who should reach out first if relevant]

Best,
Chandler
```

**Example - EdTech Connector:**
```
To: katie@example.com
Subject: Introduction to Michelle Chen (Smart Factory)

Hi Katie,

I'd like to introduce you to Michelle Chen, Director of Innovation at TechManufacturing. She's leading their Smart Factory initiative and exploring ways to integrate digital literacy training into their workforce development programs.

Given your work on adult education models with InovaEduK, there's strong alignment here. Michelle is specifically interested in training frameworks that work for manufacturing floor environments.

If you're interested in connecting, let me know and I'll make the introduction.

Best,
Chandler

---

[After Katie confirms:]

To: katie@example.com, michelle@techmanufacturing.com
Subject: Katie Rodriguez <> Michelle Chen

Katie, meet Michelle.
Michelle, meet Katie.

**Katie:** Director of Curriculum at InovaEduK, pioneering digital literacy programs for underserved communities across Latin America. She's built training models that have reached 50,000+ adults in the past two years.

**Michelle:** Director of Innovation at TechManufacturing, leading their Smart Factory transformation. She's looking at how to integrate skills training into manufacturing environments and scale it across their facilities.

**Why this connection:**
Katie's curriculum frameworks for adult learners map directly to the workforce development challenges Michelle is tackling. There's potential for collaboration on training design and possibly piloting programs at TechManufacturing facilities.

I'll let you both take it from here. Katie, maybe you could start by sharing some of the InovaEduK case studies?

Best,
Chandler
```

---

### Template 4: Status Update to Partner/Client

**When to use:** User needs to update someone on project progress

**Standard Structure:**
```
Subject: [Project Name] Update - [Date]

Hi [First Name],

Quick update on [project/partnership]:

**Progress:**
- [Accomplishment 1]
- [Accomplishment 2]

**Current Focus:**
- [What's happening now]

**Next Steps:**
- [Upcoming milestone with date]
- [Any blockers or needs]

[If question/decision needed] [Specific ask with context]

[Timeline reference for next touch point]

[Sign-off]
Chandler
```

**Example - Board Update:**
```
Subject: Q4 Portfolio Update - October 2024

Hi [Board Member],

Quick update on our Q4 progress:

**Progress:**
- InovaEduK pilot secured funding and confirmed January launch with 5 schools
- Smart Factory Phase 1 completed on time, moving to equipment integration
- Three new BD opportunities in pipeline (manufacturing sector)

**Current Focus:**
- Finalizing InovaEduK curriculum and teacher training protocols
- Smart Factory site visits and specs confirmation
- Building out partnership pipeline for Q1

**Next Steps:**
- December board meeting will include Smart Factory investment decision
- InovaEduK impact framework ready for review by mid-November
- Q1 planning complete by end of November

Any concerns or areas you'd like to discuss before the December meeting, let me know.

Best regards,
Chandler
```

**Example - Partner Status Update:**
```
Subject: Avatar Partners BD Pipeline - October Update

Hi Scott,

Quick update on partnership development:

**Progress:**
- Closed InovaEduK partnership, launch confirmed for January
- Smart Factory moving to pilot phase with TechManufacturing
- Three qualified leads in manufacturing automation space

**Current Focus:**
- Building relationship with two potential strategic partners in Brazil
- Finalizing terms for Smart Factory pilot
- Developing partnership framework for scale

**Next Steps:**
- Share detailed pipeline analysis by end of week
- Schedule partnership strategy session for early November
- Finalize Q1 targets and resource allocation

Pipeline is strong heading into Q1. Let's sync next week to review the strategic partner opportunities.

Best,
Chandler
```

---

### Template 5: Proposal or Partnership Pitch

**When to use:** User is proposing collaboration, service, or partnership

**Standard Structure:**
```
Subject: [Clear Value Proposition]

Hi [First Name],

[Context setter - how you know them or what prompted this]

[2-3 sentences on the opportunity and why it's relevant to them]

**What this looks like:**
- [Concrete element 1]
- [Concrete element 2]
- [Concrete element 3]

**Why now:**
[Timing rationale or urgency factor]

**Next step:**
[Clear call to action - meeting, call, review document]

[Relationship close that acknowledges their priorities]

[Sign-off]
Chandler
```

**Example - Partnership Proposal:**
```
Subject: Smart Factory Partnership Opportunity

Hi Michelle,

Following up on our conversation last month about TechManufacturing's digital transformation goals.

Based on what you shared about workforce challenges and automation integration, there's strong alignment with what we're building at 360. We've developed a Smart Factory model that combines automation with worker training, creating sustainable operations improvements while developing human capital.

**What this looks like:**
- Phase 1: Assessment and pilot design (6-8 weeks)
- Phase 2: Equipment integration and training deployment (3 months)
- Phase 3: Scale across facilities with performance tracking

**Why now:**
Your Q1 budget cycle timing aligns perfectly, and we have capacity to start assessment in November. Early movers in this space are seeing 30-40% efficiency gains within first year.

**Next step:**
Would you be open to a 30-minute call next week to review the framework and discuss fit? I can share case studies from similar manufacturing environments.

Looking forward to exploring this together.

Best,
Chandler
```

**Tone Considerations:**
- Lead with value, not process
- Be specific about what you're offering
- Make it easy to say yes
- Respect their time and priorities
- Show understanding of their challenges

---

### Template 6: Board/Governance Communication

**When to use:** Emailing board members or formal governance contacts

**Standard Structure:**
```
Subject: [Specific Topic] - [Board/Organization Name]

Dear [Full Name or appropriate formal address],

[Formal but warm opening]

[Context paragraph explaining situation/decision/update]

[Details organized in clear sections or bullets]

**Action Required:** [If applicable]
[Specific ask with deadline]

**Timeline:**
[Key dates or next steps]

[Professional close with appreciation]

Best regards,
Chandler Lewis
[Title if relevant]
```

**Example - Board Update:**
```
Subject: Q4 Performance Review - 360 Labs Board Meeting

Dear [Board Member Name],

I hope this message finds you well.

As we approach our December board meeting, I wanted to provide an advance summary of Q4 performance and key decisions requiring board input.

**Q4 Highlights:**
- Revenue: $2.3M (108% of target)
- New partnerships: 3 strategic additions to portfolio
- Impact: 15,000 beneficiaries reached through education initiatives

**Decision Points for December Meeting:**
1. Smart Factory expansion investment ($500K allocation)
2. Q1 2025 partnership targets and resource planning
3. Board composition and governance calendar for 2025

**Action Required:**
Please review the attached board packet and submit any questions or discussion topics by December 1st. This will help us structure the meeting agenda effectively.

**Timeline:**
- December 1: Questions and agenda input due
- December 10: Board meeting (9:00 AM - 12:00 PM)
- December 15: Meeting minutes and action items distributed

Thank you for your continued guidance and support as we close out a strong year.

Best regards,
Chandler Lewis
Executive Director, 360 Labs
```

**Tone:**
- More formal than typical emails
- Clear structure and documentation
- Explicit about decisions and actions
- Acknowledges governance role and fiduciary responsibility
- Professional appreciation without over-gratitude

---

## Cultural Communication Guidelines

### Brazilian Business Communication

**Key Characteristics:**
- Relationship-first approach
- Warmer, more personal openings
- Time for relationship building before business
- Indirect communication style (softening requests)
- Importance of trust and personal connection

**Language Considerations:**
- First names common even in formal contexts
- "Abraço" (hug) common for warm close
- "Querido/Querida" (dear) used among friends/close colleagues
- Portuguese preference shows respect

**Email Adaptations:**
- Open with personal acknowledgment or greeting
- Reference shared experiences or mutual connections
- Build context before making requests
- Close warmly (Abraço, Warmly, with appreciation)
- Offer Portuguese version when appropriate

**Example Openings:**
- "Espero que esteja tudo bem aí em São Paulo." (Hope all is well in São Paulo)
- "Foi ótimo nos encontrarmos na semana passada." (It was great to meet last week)
- "Agradeço pela conversa de ontem." (Thank you for yesterday's conversation)

**Example Closes:**
- "Abraço," (Hug - warm, common)
- "Um abraço," (A hug)
- "Warmly," (English equivalent)
- "Com carinho," (With affection - very warm)

**When to Offer Portuguese:**
- Always with Brazilian partners
- Even if they communicate in English
- Shows cultural respect and relationship investment
- Format: "*(Versão em português disponível se preferir)*"

---

### US Business Communication

**Key Characteristics:**
- Direct, efficiency-oriented
- Get to the point quickly
- Action-focused language
- Time as valuable resource
- Clear accountability and next steps

**Email Adaptations:**
- Brief, focused opening
- Lead with purpose or decision
- Use bullet points for clarity
- Explicit timelines and owners
- Professional but not overly formal

**Example Openings:**
- "Quick update on [project]:"
- "Following up on our discussion about [topic]:"
- "Wanted to touch base on [specific item]:"

**Example Closes:**
- "Best," (professional, common)
- "Thanks," (casual but professional)
- "Regards," (more formal)

**Avoid:**
- Long preambles
- Excessive context setting
- Unclear action items
- Open-ended timelines

---

### Asian Business Communication

**Key Characteristics:**
- Formal, hierarchy-conscious
- Indirect communication (saving face)
- Relationship building before business
- Group harmony over individual assertion
- Respect for authority and seniority

**Email Adaptations:**
- More formal greetings and closes
- Acknowledge position and company
- Use titles appropriately
- Soften requests and suggestions
- Show respect for process and hierarchy

**Example Openings:**
- "Dear Mr./Ms. [Last Name],"
- "I hope this message finds you well."
- "Thank you for your time and consideration."

**Example Closes:**
- "Respectfully," (shows deference)
- "With warm regards," (professional warmth)
- "Best regards," (standard formal)

**Cultural Sensitivities:**
- China: Build guanxi (relationships), show patience
- Japan: Extreme attention to hierarchy and formality
- Singapore: More direct than other Asian cultures, still formal
- South Korea: Respect for age and position, formal titles

---

### Board/Governance Communication

**Key Characteristics:**
- Formal documentation
- Clear accountability
- Fiduciary responsibility awareness
- Decision-oriented
- Professional distance while maintaining relationship

**Email Adaptations:**
- Use full names and titles
- Clear subject lines with meeting/organization reference
- Structured content with headers
- Explicit action items and timelines
- Professional but appreciative tone

**Required Elements:**
- Clear purpose statement
- Context for decisions
- Specific asks with deadlines
- Timeline for next steps
- Acknowledgment of their role

---

## Chandler's Voice Reference

### Voice Principles in Action

**Principle: Brevity with Depth**

**Good:**
"We've completed Phase 1 and confirmed three strategic partnerships for Q1. Ready to move into implementation with January timeline."

**Bad:**
"I wanted to let you know that we've been working really hard on Phase 1 and I think we're pretty much done with everything we needed to do, and I'm excited to say that we've managed to get three really good partnerships set up for the first quarter of next year, so I think we're in a good position to maybe start thinking about moving forward with the next phase, probably around January if that works for everyone."

**Why:** First version packs more information into fewer words. Second version uses filler phrases and uncertain language that wastes time.

---

**Principle: Purpose-Driven**

**Good:**
"This partnership positions us to reach 10,000 underserved students by Q2, directly advancing our mission to expand access to quality education."

**Bad:**
"We're working on a partnership that should be helpful for what we're trying to do with education stuff."

**Why:** First version connects to mission and impact. Second version is vague and doesn't explain why it matters.

---

**Principle: Strategic Alignment**

**Good:**
"The Smart Factory pilot creates a model we can replicate across manufacturing partners, building both our portfolio and our impact framework."

**Bad:**
"We're doing this Smart Factory project and it's going pretty well."

**Why:** First version shows how the project fits into broader strategy. Second version treats it as isolated activity.

---

**Principle: Authentic and Relational**

**Good:**
"Great connecting today. Your vision for expanding digital literacy aligns perfectly with what we're building."

**Bad:**
"Per our discussion earlier today, I am writing to follow up regarding the potential synergies between our respective organizational objectives."

**Why:** First version is warm and genuine. Second version is unnecessarily formal and robotic.

---

**Principle: Time is Precious**

**Good:**
"**Next steps:**
- Chandler: Share framework by Friday
- Michelle: Confirm site access by Monday
- Both: Sync next week to finalize timeline"

**Bad:**
"So I think what we should probably do next is maybe I can work on putting together some kind of framework document, and then if you could possibly let me know about the site access thing when you get a chance, and then we should probably schedule some time to talk about all this, maybe sometime next week or whenever works for you?"

**Why:** First version makes it immediately clear who does what by when. Second version requires work to extract action items.

---

### What to Avoid

**Em Dashes - NEVER USE THEM**

**Wrong:** "We completed the assessment - and it exceeded expectations - so we're ready to move forward."

**Right:** "We completed the assessment, and it exceeded expectations, so we're ready to move forward."

**Also Right:** "We completed the assessment (which exceeded expectations) so we're ready to move forward."

---

**Overly Apologetic Language**

**Wrong:** "Sorry to bother you, but I was hoping maybe you might have a chance to possibly review this when you get a moment, if it's not too much trouble."

**Right:** "Would you be able to review this by Friday?"

---

**Excessive Hedging**

**Wrong:** "I think we might potentially be able to possibly achieve something like 30% efficiency gains, if everything goes according to plan and assuming no major issues arise."

**Right:** "We're targeting 30% efficiency gains based on similar implementations."

---

**Generic Platitudes**

**Wrong:** "Excited to leverage our core competencies to drive synergistic outcomes and maximize stakeholder value."

**Right:** "This partnership lets us expand reach while building sustainable revenue."

---

**Unnecessary Formality with Established Relationships**

**Wrong (to long-time partner):** "Dear Mr. Silva, I am writing to formally request your input regarding the aforementioned matter we discussed during our previous correspondence."

**Right:** "Hi Marcio, following up on what we discussed last week about the InovaEduK timeline."

---

### Industry-Specific Vocabulary

**Education/EdTech:**
- Digital literacy (not "computer skills")
- Underserved communities (not "poor areas")
- Impact measurement (not "tracking results")
- Curriculum framework (not "lesson plans")
- Teacher training protocols
- Student outcomes
- Educational access
- Learning pathways

**Manufacturing/Industry 4.0:**
- Smart Factory
- Automation integration
- Workforce development
- Equipment specifications
- Operations efficiency
- Process optimization
- Training deployment
- Performance tracking
- Sustainable operations

**Social Impact/Development:**
- Systems change
- Stakeholder engagement
- Theory of change
- Impact metrics
- Beneficiaries (not "recipients")
- Community outcomes
- Capacity building
- Sustainable development

**Partnership Development:**
- Strategic alignment
- Value proposition
- Mutual benefit
- Collaboration framework
- Partnership terms
- Co-creation
- Pilot phase
- Scale and replication

---

## Subject Line Guidelines

**Characteristics of Effective Subject Lines:**
- Specific (not "Update" but "Q4 Partnership Update")
- Action-oriented when appropriate
- Include project/partner name for context
- Keep under 60 characters when possible
- Front-load the most important information

**Examples:**

**Good:**
- "InovaEduK Partnership - Next Steps from Today's Call"
- "Smart Factory Phase 1 Complete - Moving to Integration"
- "Introduction to Michelle Chen (TechManufacturing)"
- "Q4 Portfolio Update - October 2024"
- "Avatar Partners BD Pipeline - Action Items"

**Bad:**
- "Update" (too vague)
- "Following up" (doesn't indicate what about)
- "Quick question" (not specific)
- "Re: Our conversation" (unclear which conversation)

**Formula:**
[Project/Partner Name] - [Specific Topic/Action]

---

## Portuguese Translation Guidelines

When providing Portuguese versions of emails:

**Maintain Structure:**
- Keep same paragraph breaks
- Preserve bullet points and formatting
- Match tone and formality level

**Cultural Adaptation:**
- Brazilian Portuguese (not European Portuguese)
- Use "você" (you) for professional contexts
- Adapt idioms rather than translate literally
- Consider regional variations

**Formality Levels:**
- Formal: Use with new contacts, senior executives
- Professional: Standard business communication
- Informal: Close colleagues, established relationships

**Common Phrases:**

Formal:
- "Prezado/Prezada" (Dear - very formal)
- "Cordialmente," (Cordially - formal close)

Professional:
- "Olá" or "Oi" (Hi - common in business)
- "Atenciosamente," (Sincerely - professional close)

Informal:
- "E aí" (What's up - casual)
- "Abraço," (Hug - warm close)
- "Beijo," (Kiss - very informal, close friends)

**Translation Check:**
- Does it sound natural to a native speaker?
- Does it maintain professional tone?
- Are cultural references appropriate?
- Is the formality level correct for the relationship?

---

## Common Mistakes to Avoid

1. **Fabricating Context**: If you don't have information, mark [NEEDS CONTEXT] rather than guessing

2. **Mismatching Tone**: Using casual tone with new contact or overly formal with established partner

3. **Vague Next Steps**: "Let's connect soon" instead of "Can we schedule 30 minutes next Tuesday?"

4. **Missing Research**: Sending email without checking past conversations, calendar, or Drive

5. **Wrong Cultural Approach**: Using direct US style with Brazilian partner or informal tone with board member

6. **Long Paragraphs**: Breaking up into short paragraphs and bullets improves scannability

7. **Unclear Subject Lines**: Generic subjects that don't indicate email purpose

8. **No Timeline**: Not including when things need to happen by

9. **Em Dashes**: Using them anywhere (they're forbidden in Chandler's voice)

10. **Over-Explanation**: Providing background Claude already knows or recipient doesn't need

---

## Email Length Guidelines

**Follow-Up Emails:** 100-150 words
**Partnership Check-Ins:** 150-200 words  
**Introduction Emails:** 150-200 words (per email in double opt-in)
**Status Updates:** 150-250 words
**Proposals:** 200-300 words
**Board Communications:** 250-400 words

**When to go longer:**
- Complex board matters requiring documentation
- Proposals with multiple components
- First-time explanations of new concepts

**When to keep shorter:**
- Quick check-ins with established partners
- Simple follow-ups with clear next steps
- Status updates with no decisions needed

---

## Testing Your Draft

Before sending, ask:

1. **Would Chandler actually say this?** (Check voice)
2. **Is the relationship tone right?** (Check cultural adaptation)
3. **Are next steps crystal clear?** (Check actionability)
4. **Did I research the context?** (Check accuracy)
5. **Is anything fabricated?** (Check honesty)
6. **Are there any em dashes?** (Check formatting)
7. **Would this be easy to act on?** (Check recipient experience)
8. **Does subject line clearly indicate content?** (Check clarity)

If any answer is no, revise before presenting to user.