# Meeting Transcript Processor - Complete Documentation

## Overview

The Meeting Transcript Processor is a comprehensive skill for transforming meeting transcripts into professional deliverables across all meeting types in Chandler's work. It produces five outputs for every meeting: professional notes, follow-up email, Asana tasks, commitment tracker, and next meeting context.

## What This Skill Covers

### 14 Meeting Format Types

**CLIENT WORK (3 formats):**
1. **Client Sprint Sessions** - Recurring structured consulting work
2. **Discovery/Intake Sessions** - First meetings and needs assessment
3. **Vianeo Business Model Validation Sprints** - Assumption testing methodology

**STRATEGIC PARTNERSHIPS (2 formats):**
4. **Partner Strategy Meetings** - Two-party strategic collaboration
5. **Multi-Stakeholder Coordination** - Coalition and systems change work

**GOVERNANCE & STRUCTURE (2 formats):**
6. **Board/Governance Meetings** - Formal organizational decisions
7. **Internal Team Meetings** - Operational coordination

**CAPITAL & RESOURCES (2 formats):**
8. **Funder/Donor Meetings** - Grant-based philanthropic partnerships
9. **Investor Meetings** - Equity, debt, or impact investment

**COMMUNITY & LEARNING (3 formats):**
10. **Community Stakeholder Sessions** - Centering lived experience
11. **Workshop/Training Sessions** - Facilitated capacity building
12. **Post-Mortem/Learning Sessions** - Project reflection

**INNOVATION PORTFOLIO (1 format):**
13. **Innovation Compass Engagements** - 3-step Assess/Prioritize/Validate process

**OPERATIONAL (1 format):**
14. **Quick Sync/Decision Calls** - Rapid decision-making

## The Five-Output System

Every meeting transcript processed through this skill produces:

### 1. Professional Meeting Notes
Format varies by meeting type. Always includes:
- Clear structure matching the meeting's purpose
- Key themes, insights, or decisions
- Action items with owners
- Context for understanding if you weren't there

### 2. Follow-Up Email Draft
Tone calibrated to relationship type:
- Professional for clients
- Warm for partners
- Mission-aligned for funders
- Data-driven for investors
- Respectful for community
- Formal for governance
- Direct for internal teams

### 3. Asana Task List
With intelligent project recommendations:
- Tasks organized by owner
- Due dates (or TBD if not mentioned)
- Context notes for standalone understanding
- Project assignment based on work type

### 4. Commitment Tracker
Bilateral accountability:
- What Chandler/360 committed to
- What others committed to
- Outstanding items from previous meetings
- Dependencies and blockers

### 5. Next Meeting Context Brief
What to remember for next time:
- Where the conversation left off
- Open questions to address
- Things to watch for
- Relationship notes and cultural context

## How to Use This Skill

### Basic Usage

1. **Provide a transcript** to Claude (upload file or paste text)
2. **Say**: "Process this meeting transcript" or "Generate meeting follow-up materials"
3. **Review outputs** - Claude will automatically:
   - Identify meeting type
   - Generate all five outputs
   - Apply appropriate format and tone

### Example Prompts

**Standard request:**
> "Process these meeting notes from my call with [Partner Name]"

**With specific format:**
> "This is a Vianeo sprint session transcript. Process it please."

**With additional context:**
> "Process this board meeting transcript. Note that the finance report section needs board approval language."

**For mixed-language transcripts:**
> "This transcript has both English and Portuguese. Process it and let me know if you need clarification on any translations."

## Format Selection

### Quick Decision Guide

**First time meeting someone?** → Discovery/Intake Format

**Talking about money?**
- Grants → Funder/Donor Format
- Investment → Investor Format

**Delivering client work?**
- Regular consulting → Client Sprint Format
- Testing business assumptions → Vianeo Sprint Format
- Evaluating innovation portfolio → Innovation Compass Format

**Building partnerships?**
- One strategic partner → Partner Strategy Format
- Multiple organizations → Multi-Stakeholder Format

**Making organizational decisions?**
- Formal governance → Board/Governance Format
- Team coordination → Internal Team Format

**Engaging community or learning?**
- Stakeholder input → Community Stakeholder Format
- Training delivery → Workshop/Training Format
- Project reflection → Post-Mortem Format

**Just need a quick decision?** → Quick Sync Format

### When Formats Overlap

Some meetings blend multiple types. When this happens:
1. Choose the **primary purpose** of the meeting
2. Use that format as the base
3. Borrow relevant sections from other formats as needed

Example: A partner meeting that also involves fundraising discussion might use Partner Strategy Format as base but include investor-style terms tracking.

## Special Format Considerations

### Vianeo Business Model Validation Sprints

These follow the Vianeo methodology testing five components:
- **Legitimacy:** Strategic alignment
- **Desirability:** Market demand
- **Feasibility:** Technical implementation
- **Viability:** Financial sustainability
- **Acceptability:** Organizational readiness

Notes organize by sprint phase (Discovery/Testing/Validation/Synthesis) and track assumptions validated.

### Innovation Compass Engagements

Three-phase portfolio evaluation process:
- **Days 1-10: Assess** - GenIP 11-question evaluation
- **Days 11-14: Prioritize** - Portfolio grid and go/no-go recommendations
- **Weeks 3-5: Validate** - Deep dive on top-ranked initiatives

Notes always reference which phase and track progress toward board-ready decisions.

### Community Stakeholder Sessions

These center community voice:
- Preserve authentic language through direct quotes
- Emphasize commitments made TO community
- Acknowledge power dynamics explicitly
- Track how input influences actual decisions

### Investor Meetings

Track deal progression carefully:
- Document terms precisely for comparing offers
- Note both explicit statements and implicit signals
- Keep strategic assessment in internal notes
- Track competitive dynamics without oversharing

### Multi-Stakeholder Coordination

Balance individual organizational needs with collective action:
- Represent all organizations fairly
- Map interdependencies clearly
- Name both alignment and tension
- Clarify decision-making authority

## Style & Quality Standards

### Universal Rules

**NEVER use em dashes** - Use commas, periods, or parentheses instead

**NEVER fabricate information** - Only include what's in the transcript

**Flag uncertainties** - Use [NEEDS CLARIFICATION] for gaps

**No made-up dates** - Use "TBD" if timeline wasn't discussed

**Match relationship tone** - Calibrate to context from conversation

### Format-Specific Guidelines

**High formality** (Board, Investor):
- Structured language
- Precise documentation
- Explicit tracking of attendance/participation

**Community-centered** (Stakeholder sessions):
- Preserve authentic voice
- Avoid organizational jargon
- Center participants, not facilitators

**Learning-focused** (Workshop, Post-Mortem):
- Emphasize insights and takeaways
- Honest about what didn't work
- Make learning actionable

**Strategic** (Partner, Multi-Stakeholder, Innovation):
- Connect to broader context
- Show trajectory, not just current state
- Name power dynamics explicitly

## Language & Cultural Considerations

### Mixed-Language Transcripts

**Meeting notes:** Keep original language for quotes, translate key points

**Follow-up emails:** Draft in English, note if Portuguese version should be offered

**Flag uncertainties:** Note sections where translation might affect meaning

### Cultural Context

**Latin America (especially Brazil):**
- More relationship-building before business
- Indirect communication style
- Longer timeline for decision-making

**Note in outputs:** Communication style preferences for follow-up

## Common Scenarios

### Scenario 1: Clear Single Format
**Situation:** Weekly client sprint call for ongoing consulting project
**Action:** Use Client Sprint Session Format
**Output:** Standard five deliverables

### Scenario 2: First Meeting
**Situation:** Initial call with potential partner to explore collaboration
**Action:** Use Discovery/Intake Format
**Output:** Includes fit assessment and decision timeline in notes

### Scenario 3: Investment Discussion
**Situation:** Meeting with impact investor about Series A funding
**Action:** Use Investor Meeting Format
**Output:** Tracks deal structure, terms, due diligence, and strategic assessment

### Scenario 4: Portfolio Evaluation
**Situation:** Innovation Compass session prioritizing five initiatives
**Action:** Use Innovation Compass Format
**Output:** References Compass phase, tracks initiatives across priority grid

### Scenario 5: Mixed Purpose Meeting
**Situation:** Partner call that covers both strategic collaboration and fundraising
**Action:** Use Partner Strategy Format as base, add investor-style sections for funding discussion
**Output:** Hybrid approach noted in meeting notes header

### Scenario 6: Community Input Session
**Situation:** Facilitated session with 15 community members about program design
**Action:** Use Community Stakeholder Format
**Output:** Centers community voice, tracks commitments to participants

### Scenario 7: Quick Decision Call
**Situation:** 20-minute call to unblock work and make go/no-go decision
**Action:** Use Quick Sync Format
**Output:** Ultra-concise but still produces all five deliverables

### Scenario 8: Learning Session
**Situation:** Team retrospective after completing major project
**Action:** Use Post-Mortem Format
**Output:** Focuses on learning, honest assessment, and application plan

## Troubleshooting

### "I can't tell what format to use"

**Try this:**
1. Look at attendees (internal, external, power dynamics)
2. Identify primary purpose (decision, learning, validation, coordination)
3. Check for methodology clues (Vianeo, Innovation Compass)
4. Use closest format and note uncertainty

**Ask Claude:** "Which format should I use for this transcript?" with brief context

### "The transcript is unclear or incomplete"

Claude will:
- Produce outputs based on available information
- Flag gaps with [NEEDS CLARIFICATION]
- Note in email that clarification needed
- Suggest questions to fill gaps

**You can help by:** Providing additional context about meeting purpose or relationships

### "The meeting covered multiple topics"

This is normal! Claude will:
- Choose dominant format
- Borrow sections from other formats as needed
- Note in output which format was used and why

### "Cultural context is ambiguous"

Claude will:
- Default to professional but warm tone
- Avoid assumptions about hierarchy
- Note in next meeting brief that context should be confirmed

**You can specify:** "This partner prefers more formal communication" or "This is a casual collaborative relationship"

## File Structure

```
meeting-transcript-processor/
├── SKILL.md                          # Main skill instructions for Claude
├── README.md                         # This file - comprehensive documentation
├── references/
│   ├── meeting-formats.md            # All 14 format templates
│   ├── email-guide.md                # Email tone and structure guide
│   ├── style-guide.md                # Chandler's communication style
│   └── project-logic.md              # Asana project assignment rules
└── scripts/
    └── validate_output.py            # Quality validation script
```

## Version Information

**Current Version:** 3.0.0

**Major Updates in 3.0:**
- Expanded from 4 to 14 meeting format types
- Added Innovation Compass engagement format
- Added Vianeo business model validation sprint format
- Added investor, funder/donor, discovery/intake formats
- Added community stakeholder, multi-stakeholder formats
- Added workshop/training, post-mortem/learning formats
- Added quick sync/decision call format
- Enhanced format-specific guidance throughout
- Comprehensive format selection decision tree

## Best Practices

### For Best Results

1. **Provide complete transcripts** - More context = better outputs
2. **Include attendee names** - Helps with relationship calibration
3. **Note meeting type if obvious** - Speeds up processing
4. **Flag cultural context** - Especially for international partners
5. **Specify urgent items** - If certain actions need priority

### Quality Indicators

Good outputs will have:
- Clear, scannable structure
- Action items with owners and dates
- No fabricated information
- Appropriate tone for relationship
- Useful context for next meeting

### When to Iterate

Ask Claude to revise if:
- Tone doesn't match relationship
- Format doesn't fit meeting type
- Action items miss key commitments
- Next meeting brief lacks important context

## Support & Feedback

This skill is actively maintained and improved based on usage. If you encounter:
- **Format gaps** - Meeting types not covered well
- **Quality issues** - Outputs not matching standards
- **New needs** - Additional output types needed

Document the issue and discuss with Chandler for skill updates.

## Quick Reference Card

### The Five Outputs (Always)
1. Professional meeting notes (format varies)
2. Follow-up email draft (tone varies)
3. Asana task list (with project suggestion)
4. Commitment tracker (bilateral)
5. Next meeting context brief

### Format Selection Shorthand
- First meeting? → Discovery
- Money talk? → Funder (grants) or Investor (equity)
- Client work? → Sprint, Vianeo, or Compass
- Partnership? → Partner or Multi-Stakeholder
- Governance? → Board or Team
- Community/Learning? → Stakeholder, Workshop, or Post-Mortem
- Quick decision? → Quick Sync

### Critical Rules
- No em dashes (ever)
- No fabrication (ever)
- Flag gaps with [NEEDS CLARIFICATION]
- Use TBD for uncertain dates
- Match relationship tone

### Common Prompts
- "Process this meeting transcript"
- "Generate follow-up materials from these notes"
- "This is a [format type] meeting, process it please"
- "Process this and let me know if anything needs clarification"
