# Project Assignment Logic Reference

This document explains how to determine the correct Asana project for tasks generated from meeting transcripts.

## Contents
- Project Assignment Decision Tree
- Project Categories
- When to Flag for Manual Assignment

---

## Project Assignment Decision Tree

```
Is this a sprint client? (Vianeo, consulting engagements)
├─ YES: Do they have a dedicated project?
│  ├─ YES → Use their dedicated project
│  └─ NO → Use "Weekly Meeting Tracker"
│
└─ NO: Is this a strategic partner?
   ├─ YES: Which type of partner?
   │  ├─ NWK partners → "NWK Global Partnership Development"
   │  ├─ Other partners with dedicated project → Use that project
   │  └─ Partners without dedicated project → "Weekly Meeting Tracker"
   │
   └─ NO: Is this a CNEN project?
      ├─ YES: Which CNEN initiative?
      │  ├─ Specific project exists → Use specific project tracker
      │  └─ No specific project → "CNEN Meeting Hub"
      │
      └─ NO: Is this internal?
         ├─ YES → "Weekly Meeting Tracker"
         └─ UNCLEAR → Flag with "[NEEDS PROJECT ASSIGNMENT]"
```

---

## Project Categories

### Sprint Clients

**Characteristics:**
- Ongoing consulting relationships
- Regular sprint sessions
- Structured deliverables and milestones
- Often have dedicated projects in Asana

**Known Sprint Clients:**
- Vianeo
- [Add other sprint clients as they're identified]

**Project assignment:**
1. Check if client has dedicated project (look for project named after client/engagement)
2. If yes, use that project
3. If no, use "Weekly Meeting Tracker" and note in task description which client

**Task naming convention:**
- [Client Name]: [Task description]
- Example: "Vianeo: Update product roadmap reflecting K-5 focus"

---

### Strategic Partners

**Characteristics:**
- Partnership discussions
- Business development
- Long-term collaboration focus
- May or may not have dedicated projects

**Subcategories:**

#### NWK Partners
**Definition:** Partners connected through NWK Global network

**Project:** "NWK Global Partnership Development"

**Indicators in transcript:**
- Mention of NWK Global
- Introduction through NWK network
- References to other NWK partners

**Task naming convention:**
- [Partner Name] - [Task description]
- Example: "Avatar Partners - Share partnership framework documentation"

#### Other Strategic Partners
**Definition:** Direct partnerships not through NWK

**Project assignment:**
1. Check if partner has dedicated project
2. If yes, use that project
3. If no, use "Weekly Meeting Tracker"

**Indicators:**
- Partnership/collaboration language
- Discussion of joint ventures or shared initiatives
- Long-term strategic alignment

---

### CNEN Projects

**Characteristics:**
- Related to CNEN (likely a specific organization or initiative based on context)
- Government/institutional partnerships
- Complex stakeholder management

**Project assignment:**
1. If specific CNEN project tracker exists (e.g., "CNEN Education Initiative"), use that
2. If general CNEN work, use "CNEN Meeting Hub"
3. If unclear which CNEN initiative, flag with "[NEEDS PROJECT ASSIGNMENT - Which CNEN project?]"

**Task naming convention:**
- CNEN: [Task description]
- Example: "CNEN: Prepare compliance documentation for Q4 review"

---

### Internal Team Meetings

**Characteristics:**
- Team check-ins
- Operational discussions
- Internal planning and coordination
- No external stakeholders

**Project:** "Weekly Meeting Tracker"

**Task naming convention:**
- [Area/Topic]: [Task description]
- Example: "Product: Review user feedback from pilot schools"

---

### Board/Governance

**Characteristics:**
- Board meetings
- Governance discussions
- Organizational oversight

**Project assignment:**
1. If "Board Governance" or similar project exists, use that
2. Otherwise, use "Weekly Meeting Tracker"
3. Tag tasks with "board" or "governance" label if possible

**Task naming convention:**
- Board: [Task description]
- Example: "Board: Prepare Q4 financial summary for December meeting"

---

## When to Flag for Manual Assignment

Use "[NEEDS PROJECT ASSIGNMENT]" tag when:

1. **Meeting involves multiple project areas**
   - Example: Sprint client meeting that also discussed a partnership opportunity
   - Action: List both potential projects in the note

2. **New client or partner not yet in the system**
   - Example: First meeting with a potential new consulting client
   - Action: Flag and note "New client - may need dedicated project"

3. **Cross-organizational initiative**
   - Example: Meeting about initiative spanning multiple teams/partners
   - Action: Note the stakeholders involved so correct project can be identified

4. **Unclear from transcript**
   - Example: Vague references without clear organizational context
   - Action: Include context clues from transcript so manual assignment can be made

---

## Task Assignment Guidelines

### Who gets assigned what?

**Chandler Lewis:**
- Strategic tasks (partnership development, high-level decisions)
- External relationship management
- Board/governance items
- Final approvals and sign-offs

**Eduardo/Felipe:**
- Financial modeling and analysis
- Technical implementation
- Operational execution
- Detailed project work

**Team (Eduardo/Felipe/Claude):**
- When unclear who should own it
- Collaborative tasks requiring multiple people
- Tasks that need to be delegated in real-time

**External Partners/Clients:**
- Their commitments and action items
- Information they need to provide
- Decisions they need to make

### When to be specific vs. general

**Be specific about assignee when:**
- Person was explicitly named in the meeting
- Task clearly falls in someone's domain (e.g., financial tasks → Eduardo)
- Accountability is critical

**Use general "Team" assignment when:**
- Task could be done by multiple people
- Will be delegated/discussed after the meeting
- Collaborative effort required

---

## Project Assignment Examples

### Example 1: Sprint Client with Dedicated Project
**Transcript context:** "Vianeo Sprint Session - discussing Q4 roadmap priorities"

**Project assignment:** Vianeo Project (if exists) or "Weekly Meeting Tracker"

**Tasks:**
```
Chandler Lewis:
- Vianeo: Update product roadmap reflecting K-5 focus | Due: Nov 1

Eduardo:
- Vianeo: Financial model for revised timeline | Due: Nov 5
```

---

### Example 2: NWK Partner Meeting
**Transcript context:** "Meeting with Avatar Partners about AI education platform collaboration, introduced through NWK Global network"

**Project assignment:** "NWK Global Partnership Development"

**Tasks:**
```
Chandler Lewis:
- Avatar Partners: Share partnership framework documentation | Due: Nov 10
- Avatar Partners: Schedule technical deep-dive with Felipe | Due: Nov 15

Avatar Partners:
- Provide API documentation and integration requirements | Due: Nov 20
```

---

### Example 3: CNEN Initiative
**Transcript context:** "CNEN quarterly review - discussing compliance requirements and reporting"

**Project assignment:** "CNEN Meeting Hub" or specific CNEN project if identified

**Tasks:**
```
Chandler Lewis:
- CNEN: Prepare compliance documentation for Q4 review | Due: Dec 1

Team (Eduardo/Felipe/Claude):
- CNEN: Compile quarterly impact metrics | Due: Nov 25 | Notes: Need data from pilot schools
```

---

### Example 4: Internal Planning
**Transcript context:** "360 team sync about Q1 planning and resource allocation"

**Project assignment:** "Weekly Meeting Tracker"

**Tasks:**
```
Chandler Lewis:
- Review and approve Q1 hiring plan | Due: Nov 30

Eduardo:
- Finalize Q1 budget allocation | Due: Nov 28

Felipe:
- Infrastructure scaling plan for Q1 | Due: Dec 5
```

---

### Example 5: Complex Multi-Project Meeting
**Transcript context:** "Meeting with InovaEduK about both their current consulting engagement AND exploring a long-term partnership opportunity"

**Project assignment:** "[NEEDS PROJECT ASSIGNMENT]"

**Note in recommendation:**
"Recommend splitting tasks:
- Consulting deliverables → InovaEduK Sprint Project (if exists)
- Partnership exploration → Weekly Meeting Tracker or create new InovaEduK Partnership project"

**Tasks:**
```
Chandler Lewis:
- InovaEduK: Deliver Sprint 3 recommendations | Due: Nov 15 | Project: [InovaEduK Sprint Project]
- InovaEduK: Draft partnership framework options | Due: Nov 30 | Project: [NEEDS ASSIGNMENT]
```

---

## Default Fallback

**When in doubt:** Use "Weekly Meeting Tracker" and include context in the task description.

**Better to:**
- Use Weekly Meeting Tracker with good task description
- Include context clues about which project it might belong to

**Than to:**
- Guess wrong and put in inappropriate project
- Leave ambiguous with no guidance

**Remember:** The goal is to make it easy for Chandler to act on tasks. A clear task in the Weekly Meeting Tracker is better than a poorly-placed task in the "wrong" project.
