# Style Guide Reference

This document captures Chandler's communication principles and voice guidelines.

## Contents
- Core Communication Principles
- Meeting Notes Style
- Email Style
- What to Avoid
- Voice Examples

---

## Core Communication Principles

### 1. Brevity with Depth
**What it means:** No fluff, but don't skip substance.

**In practice:**
- Every sentence should add value
- Cut unnecessary words, but include necessary context
- Prefer "We'll launch in Q2 because it aligns with the school calendar" over "We have decided that we will be launching our program in the second quarter of next year, and the reason for this timing decision is that it aligns well with the academic school calendar"
- Also avoid: "Let's launch Q2" without the "why" when the why matters

**When to apply:**
- All written communication
- Especially important for executive/board communications
- Less critical in relationship-building contexts where warmth matters

### 2. Purpose-Driven
**What it means:** Connect to why, not just what.

**In practice:**
- Link actions to outcomes or values
- Help people see how pieces fit together
- Make the "so what?" clear

**Example:**
- Weak: "We need to update the curriculum."
- Strong: "Updating the curriculum now positions us for accreditation by Q3, which opens up the public school partnerships we've been pursuing."

**When to apply:**
- Strategic communications
- Action items that need buy-in
- Explaining decisions or priorities

### 3. Strategic Alignment
**What it means:** Show how this fits the bigger picture.

**In practice:**
- Connect dots across initiatives
- Surface implications and tradeoffs
- Think systems, not just tasks

**Example:**
- Tactical: "Schedule a meeting with the literacy program team."
- Strategic: "Meeting with literacy team connects to the broader early education strategy and could inform our approach to the São Paulo expansion."

**When to apply:**
- Partnership discussions
- Organizational decisions
- Long-term planning

### 4. Authentic and Relational
**What it means:** Professional but human.

**In practice:**
- Write like you talk (but edited)
- Show warmth without being fake
- Acknowledge complexity and uncertainty when real
- Use "I" and "we" not impersonal passive voice

**Example:**
- Stiff: "It has been determined that the aforementioned approach would be optimal."
- Better: "We think this approach makes the most sense given what we know now."

**When to apply:**
- All communication, but especially:
- Relationship-building conversations
- Sensitive topics
- Team communication

### 5. Time is Precious
**What it means:** Make it easy to act on.

**In practice:**
- Front-load the most important information
- Use structure to enable scanning
- Clear calls to action
- Remove cognitive load where possible

**Example structure for busy stakeholders:**
```
TLDR: [One sentence bottom line]

Context: [Why this matters]

What I need from you: [Specific, clear ask]

Background: [Only if they want to go deeper]
```

**When to apply:**
- Emails to busy people
- Executive updates
- Board communications
- Anywhere decision-makers are time-constrained

---

## Meeting Notes Style

### Tone: Professional, Factual, Organized

**Characteristics:**
- Third-person or neutral perspective
- Focus on substance over process
- Organized by logic/theme, not chronology
- Includes context for someone who wasn't there

### Organization Principles

**By theme, not timeline:**
- Bad: "First we talked about X, then someone mentioned Y, then we circled back to Z"
- Good: Organize under clear headers that reflect content categories

**Complete but efficient:**
- Include enough that an absent stakeholder understands what happened
- Don't transcribe everything verbatim
- Capture the essence, decisions, and implications

**Quotes sparingly:**
- Only use direct quotes when the exact wording matters
- When you do quote, make it count (memorable insight, important framing, commitment)

### Structure Examples

**Thematic organization:**
```
## Key Themes Explored
- Budget constraints and resource allocation
- Timeline considerations for Q2 launch
- Partnership structure and governance

## Budget Discussion
[Substantive summary of what was covered, decisions made, implications]

## Timeline Discussion
[Substantive summary...]
```

**Decision-focused organization:**
```
## Decisions Made
1. [Decision] - Rationale: [Why]
2. [Decision] - Rationale: [Why]

## Implementation Considerations
[What came up regarding how to execute on the decisions]

## Outstanding Questions
[What still needs resolution]
```

### Level of Detail

**Right level:**
- Captures reasoning, not just conclusions
- Includes important context and constraints
- Notes dissent or alternative views if meaningful
- Records assumptions that might change

**Too much:**
- Play-by-play of who said what when
- Tangential discussions that went nowhere
- Detailed explanations of obvious points
- Repeated restatements of the same point

**Too little:**
- Just listing decisions with no context
- Omitting important considerations or tradeoffs
- Missing the "why" behind choices
- No indication of what's still uncertain

---

## Email Style

### Tone: Clear, Warm, Actionable

**Characteristics:**
- Gets to the point quickly
- Easy to scan
- Respectful of recipient's time
- Warm but not overly casual
- Never apologetic unless genuine apology needed

### Structure Priorities

**Lead with value:**
- Open with why this matters or what's most important
- Don't bury the lede

**Make action items obvious:**
- Use formatting (bold, bullets) to make them stand out
- Be explicit about who does what by when

**One clear call to action:**
- Don't overwhelm with multiple asks
- If multiple things needed, prioritize or sequence them

### Language Choices

**Active, direct language:**
- "I'll send the proposal by Friday" not "The proposal will be sent"
- "Can you review this by Tuesday?" not "If you have time, it would be great if you could possibly take a look at this when you get a chance"

**Confident without arrogance:**
- "I recommend we proceed with Option A because..." not "We should obviously do Option A"
- "Based on what we know, Option A makes sense" not "Option A might potentially be worth considering possibly"

**Warm without being overly casual:**
- "Thanks for making time for this" not "Hey thanks a ton for squeezing this in, I know you're super busy"
- "Looking forward to moving this forward" not "So excited to do this!!! 🎉"

### Email Anti-Patterns to Avoid

**Don't:**
- Open with apologies ("Sorry to bother you...")
- Hedge excessively ("I was just thinking maybe we could possibly...")
- Use em dashes anywhere
- Write paragraphs longer than 3-4 sentences
- End with vague "let me know if you have any questions"

**Do:**
- State your purpose clearly
- Make asks specific
- Provide context efficiently
- End with clear next steps

---

## What to Avoid

### 1. Em Dashes
**Never use them.** Use commas, periods, or parentheses instead.

**Wrong:** "The partnership — which we've been developing for months — is ready to launch"
**Right:** "The partnership (which we've been developing for months) is ready to launch"
**Right:** "The partnership, which we've been developing for months, is ready to launch"

### 2. Unnecessary Hedging
**Problem:** Makes you sound uncertain when you're not.

**Examples to avoid:**
- "I think maybe we could possibly..."
- "It seems like perhaps..."
- "I was just wondering if..."

**Better:**
- "We should..."
- "This makes sense because..."
- "Can we...?"

**Exception:** Genuine uncertainty should be acknowledged clearly, not hedged vaguely.
- Good: "I'm not certain about the timeline, but my best estimate is Q2"
- Bad: "It might possibly be around Q2 or so, potentially"

### 3. Excessive Formality
**Problem:** Creates distance, sounds stilted.

**Avoid:**
- "As per our discussion..."
- "Please be advised that..."
- "It has come to my attention..."
- "Enclosed please find..."

**Better:**
- "Following up on our conversation..."
- "I wanted to let you know..."
- "I noticed..."
- "Attached is..." or "Here's..."

### 4. Walls of Text
**Problem:** Hard to read, easy to miss important points.

**Avoid:**
- Paragraphs longer than 4-5 sentences
- No white space or structure
- Everything in one continuous flow

**Better:**
- Break into short paragraphs
- Use headers for longer documents
- Use bullets for lists
- Use bold sparingly for key points

### 5. Apologizing for Non-Problems
**Problem:** Undermines confidence, wastes words.

**Don't say:**
- "Sorry to bother you..."
- "Sorry if this is a dumb question..."
- "Sorry for the long email..."

**Instead:**
- Just ask or say what you need to say
- If truly too long, make it shorter
- Save apologies for actual mistakes

---

## Voice Examples

### Example 1: Strategic Update (Good)

"We're shifting the São Paulo launch from Q1 to Q2. The delay aligns with the school calendar and gives us time to complete the certification process, which opens up public school partnerships. Trade-off: we miss some early momentum, but we gain a stronger position for sustainable growth.

Next steps: Updated timeline to the board by Friday, partnership conversations begin in January."

**Why it works:**
- Clear decision stated upfront
- Explains rationale (school calendar, certification)
- Acknowledges tradeoff honestly
- Connects to larger goal (sustainable growth)
- Concrete next steps

### Example 2: Partnership Email (Good)

"Hi Ana,

Thanks for the thoughtful conversation about potential collaboration. Your emphasis on community ownership really resonated with our approach.

Based on our discussion, I'm seeing strong alignment on values and complementary strengths on execution. The question seems to be timing and resource availability on your side.

**Next steps:**
- I'll send case studies from similar partnerships by next week
- You'll check with your team about Q1 capacity
- We'll reconnect mid-December to decide if this makes sense to pursue

Looking forward to seeing where this goes.

Chandler"

**Why it works:**
- Acknowledges the relationship aspect (her emphasis on community)
- Synthesizes what was learned without rehashing everything
- Names the question directly (timing and resources)
- Clear, specific next steps
- Warm but professional close

### Example 3: Meeting Notes (Good)

"# Vianeo Sprint Session - Strategy Alignment

**Date:** Oct 24, 2025

## Key Themes Explored
- Market positioning in the remote learning space
- Target customer segment prioritization
- Resource allocation for Q4

## Critical Decisions

**Focus on K-5 segment first**
Rationale: Stronger product-market fit, existing relationships in this space, and clearer path to revenue in Q4. The secondary education segment remains a future priority but requires more product development.

**Delay international expansion to 2026**
Rationale: Resource constraints and the need to solidify domestic market position. This decision is contingent on hitting Q4 revenue targets; if we exceed projections, we'll revisit in Q1.

## Action Items

**360 Team:**
- Update product roadmap reflecting K-5 focus by Nov 1 (Chandler)
- Financial model for revised timeline by Nov 5 (Eduardo)

**Vianeo Team:**
- Introduce us to K-5 school contacts by Nov 10 (Maria)
- Feedback on revised positioning by Nov 15 (whole team)

## Information Gaps
- Competitive landscape analysis for K-5 remote learning (needed before next session)
- Customer interview data from pilot schools (in progress, due Nov 20)"

**Why it works:**
- Organized by theme and logic, not chronology
- Decisions include rationale and contingencies
- Action items are specific with owners and dates
- Notes what's still unknown
- Professional but not stiff

---

## Applying the Style Guide

**General principle:** The style guide describes ideal patterns. Apply judgment about when to deviate based on context.

**Always apply:**
- Never use em dashes
- Brevity with depth
- Time is precious (make it easy to act on)

**Context-dependent:**
- Strategic alignment (essential for high-level communications, less critical for routine operational items)
- Warmth level (adjust based on relationship and cultural context)
- Level of formality (more in new relationships, less with established partners)

**The goal:** Communication that feels distinctly like Chandler, authentic in voice, strategic in substance, and respectful of everyone's time.
