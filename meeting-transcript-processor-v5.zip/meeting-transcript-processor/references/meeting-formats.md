# Meeting Formats Reference

This document contains detailed format templates for different types of meetings across Chandler's work.

## Contents

**Client Work:**
- Client Sprint Session Format
- Discovery/Intake Session Format
- Vianeo Business Model Validation Sprint Format

**Strategic Partnerships:**
- Partner Strategy Meeting Format
- Multi-Stakeholder Coordination Meeting Format

**Governance & Structure:**
- Board/Governance Meeting Format
- Internal Team Meeting Format

**Capital & Resources:**
- Funder/Donor Meeting Format
- Investor Meeting Format

**Community & Learning:**
- Community Stakeholder Session Format
- Workshop/Training Session Format
- Post-Mortem/Learning Session Format

**Innovation Portfolio:**
- Innovation Compass Engagement Format

**Operational:**
- Quick Sync/Decision Call Format

---

## Client Sprint Session Format

**Use for:** Vianeo engagements, consulting projects, and structured client work sessions with clear deliverables.

```
# [Project Name] - [Session Type] Meeting Notes

**Date:** [Date]
**Duration:** [Length]
**Attendees:**
- **360 Team:** [Names and roles]
- **Client Team:** [Names and roles]

---

## Key Themes Explored
[3-5 main topics with brief context]
- Theme 1: [One sentence]
- Theme 2: [One sentence]
- Theme 3: [One sentence]

## Critical Questions & Answers
[Most important Q&As from the discussion]
1. **Q:** [Question]
   **A:** [Concise answer]

2. **Q:** [Question]
   **A:** [Concise answer]

## Major Insights & Breakthroughs
[Significant discoveries or strategic shifts]
- [Insight 1]
- [Insight 2]

*If none: "No major strategic shifts; session focused on information gathering/validation."*

## Action Items

**360 Team:**
- [Action] - Owner: [Name] - Due: [Date or TBD]
- [Action] - Owner: [Name] - Due: [Date or TBD]

**Client Team:**
- [Action] - Owner: [Name] - Due: [Date or TBD]
- [Action] - Owner: [Name] - Due: [Date or TBD]

## Information Gaps & Next Steps

**Outstanding Information Needed:**
- [Item 1]
- [Item 2]

**Next Meeting Focus:**
- [Topic areas to prioritize]
- [Required attendees if specific people needed]
```

**Format Notes:**
- Focus on themes and insights, not chronological recap
- Capture Q&A when it reveals important understanding
- Be explicit about what still needs to be learned
- Action items should be specific and have clear owners

---

## Partner Strategy Meeting Format

**Use for:** Partnership discussions, business development, and strategic collaboration meetings.

```
# [Partner/Company Name] Meeting Notes

**Date:** [Date]
**Attendees:** [Names]

## Discussion Summary
[2-3 paragraphs covering main topics]

First paragraph: Core topic or main purpose of the meeting.

Second paragraph: Key discussion points, considerations raised, or strategic angles explored.

Third paragraph (if needed): Implications, next phase thinking, or broader context.

## Decisions Made
- [Decision 1 with brief rationale]
- [Decision 2 with brief rationale]

*If no firm decisions: "Discussion focused on exploration and alignment; formal decisions deferred to [timeframe or trigger]."*

## Action Items
- **Chandler:** [items with due dates]
- **[Partner Name]:** [items with due dates]
- **Shared/Coordination:** [items requiring both parties]

## Next Steps
[What happens next, timeline, focus areas]
- Near-term (next 1-2 weeks): [specific actions]
- Medium-term (this quarter): [direction or milestones]
- Long-term considerations: [strategic thinking to revisit]
```

**Format Notes:**
- Streamlined for efficiency, relationship-focused
- Decisions section is critical, note explicitly if none were made
- Next steps should show clear path forward

---

## Board/Governance Meeting Format

**Use for:** Board meetings, governance discussions, and formal organizational decision-making.

```
# [Organization Name] - [Meeting Type] Minutes

**Date:** [Date]
**Time:** [Start] to [End]
**Location/Format:** [Physical location or virtual platform]

**Present:**
- [Name, Title/Role]
- [Name, Title/Role]

**Absent/Apologies:**
- [Name, Title/Role]

---

## Agenda Items

### 1. [Agenda Item Title]
**Presented by:** [Name]

**Discussion:**
[Summary of key points raised, questions asked, and perspectives shared]

**Decision/Resolution:**
[Formal decision made, or note if tabled/deferred]

**Action Items:**
- [Action] - Owner: [Name] - Due: [Date]

---

### 2. [Agenda Item Title]
[Repeat structure above for each agenda item]

---

## Key Decisions Summary
1. [Decision] - [Brief context]
2. [Decision] - [Brief context]

## Action Items Register
**[Person Name]:**
- [Action] - Due: [Date]
- [Action] - Due: [Date]

**[Person Name]:**
- [Action] - Due: [Date]

## Next Meeting
**Date:** [Date or TBD]
**Focus:** [Key topics for next meeting]
**Materials Needed:** [Any prep work or documents required]
```

**Format Notes:**
- More formal tone and structure
- Track attendance explicitly
- Follow agenda structure closely
- Decisions and resolutions must be clear and documented
- Action items register consolidates all commitments

---

## Internal Team Meeting Format

**Use for:** Team check-ins, project syncs, and internal operational discussions.

```
# [Team/Project Name] - [Meeting Purpose]

**Date:** [Date]
**Attendees:** [Names]

## Updates & Progress
[Brief updates from team members, organized by person or workstream]

**[Person/Area]:**
- [Update 1]
- [Update 2]

**[Person/Area]:**
- [Update 1]
- [Update 2]

## Issues & Blockers
[Problems that need attention or decisions]
- [Issue 1] - Status: [How being addressed]
- [Issue 2] - Status: [How being addressed]

*If none: "No significant blockers; team making steady progress."*

## Decisions & Agreements
- [Decision/agreement reached]
- [Decision/agreement reached]

## Action Items
**[Name]:**
- [Action] - Due: [Date]

**[Name]:**
- [Action] - Due: [Date]

## Upcoming Priorities
[What the team is focusing on in the immediate future]
- Next sprint/week: [Focus areas]
- Upcoming deadlines: [Key dates]
```

**Format Notes:**
- Action-focused, minimal ceremony
- Capture blockers explicitly so they get addressed
- Updates should be concise (not play-by-play)
- Emphasize forward momentum and priorities

---

## Funder/Donor Meeting Format

**Use for:** Foundation conversations, philanthropic partners, and grant-based funding discussions.

```
# [Foundation/Funder Name] Meeting Notes

**Date:** [Date]
**Meeting Type:** [Initial Conversation/Grant Check-in/Impact Reporting/Strategic Discussion]
**Attendees:**
- **[Your Organization]:** [Names and roles]
- **[Funder]:** [Names and roles]

## Meeting Purpose
[1-2 sentences on what this conversation was about]

## Impact Update
[Progress on grant deliverables or program outcomes]

**Milestones Achieved:**
- [Milestone] - [Brief description of impact]
- [Milestone] - [Brief description of impact]

**Key Metrics/Outcomes:**
- [Metric] - [Result and context]
- [Metric] - [Result and context]

## Discussion Points

### Strategic Alignment
[How work aligns with funder priorities or evolving mission focus]

### Challenges & Adaptations
[Any obstacles encountered and how you're addressing them]

### Learning & Insights
[What you've learned that might inform their broader portfolio or strategy]

## Funding Status & Next Steps

**Current Grant:**
- Status: [On track/Modifications needed]
- Timeline: [Key dates]
- Remaining deliverables: [What's outstanding]

**Future Opportunities:**
[Any discussion of continued partnership, new initiatives, or expanded scope]

## Action Items
**[Your Organization]:**
- [Action] - Owner: [Name] - Due: [Date]

**[Funder]:**
- [Action] - Contact: [Name] - Expected: [Date]

## Relationship Notes
[Communication preferences, program officer insights, strategic interests, cultural considerations]
```

**Format Notes:**
- Balance accountability with partnership tone
- Emphasize impact narrative and mission outcomes
- Be transparent about challenges
- Connect your work to their broader strategic goals
- Track both formal deliverables and relationship development

---

## Discovery/Intake Session Format

**Use for:** First meetings with potential clients or partners to assess needs, scope work, and evaluate fit.

```
# [Organization/Individual Name] - Discovery Session

**Date:** [Date]
**Attendees:**
- **360 Team:** [Names and roles]
- **Prospect:** [Names and roles]

## Organization Context
[Brief background on who they are, what they do, and why they're reaching out]

## Current Situation
[What's happening now that prompted this conversation]

**Challenge/Opportunity:**
[The problem they're trying to solve or opportunity they want to pursue]

**What They've Tried:**
[Previous approaches, existing resources, current state]

**Urgency/Timeline:**
[When they need to make progress and why]

## Needs Assessment

**Stated Needs:**
- [Need 1]
- [Need 2]

**Underlying Needs:** (observed but not explicitly stated)
- [Insight about what might really be needed]

**Constraints:**
- Budget: [Range or considerations]
- Timeline: [Requirements or flexibility]
- Internal capacity: [Team availability, decision-making authority]
- Other: [Political dynamics, organizational readiness, etc.]

## Potential Scope Discussion
[High-level conversation about what engagement might look like]

**Possible Approaches:**
- Option 1: [Brief description]
- Option 2: [Brief description]

**Questions We Still Need Answered:**
- [Question 1]
- [Question 2]

## Fit Assessment

**Strong Alignment:**
- [Why this could be a good fit]

**Potential Concerns:**
- [Any red flags or misalignment to consider]

**Decision Criteria:**
[What would make this a yes/no for both parties]

## Next Steps
- **Immediate:** [What happens in next 1-2 weeks]
- **Decision Timeline:** [When both parties will decide on engagement]
- **Materials to Share:** [Proposals, case studies, references, etc.]

## Internal Notes
[Strategic considerations, pricing thoughts, team fit, priority level]
```

**Format Notes:**
- Listen more than you pitch in the notes
- Capture both surface-level and deeper needs
- Be honest about fit in internal assessment
- Track decision-making process and key influencers
- Note any cultural or relationship considerations

---

## Community Stakeholder Session Format

**Use for:** Community input sessions, stakeholder engagement, and centering lived experience in program design.

```
# [Community/Initiative Name] - Stakeholder Session

**Date:** [Date]
**Format:** [In-person/Virtual/Hybrid]
**Facilitators:** [Names]
**Participants:** [Number and description, e.g., "12 community members from X neighborhood"]

## Session Purpose
[What we aimed to learn or accomplish together]

## Participant Contributions

### Theme 1: [Topic Area]
[Synthesized input from participants, preserving voice and perspective]

**What We Heard:**
- [Key point raised by participants]
- [Key point raised by participants]

**Direct Quotes:** (when particularly powerful or illustrative)
> "[Quote]" - [First name or role if anonymous]

### Theme 2: [Topic Area]
[Repeat structure for each major theme]

## Priorities & Preferences
[What participants identified as most important, urgent, or valuable]

**Top Priorities:**
1. [Priority] - Why it matters: [Context from participants]
2. [Priority] - Why it matters: [Context from participants]

## Concerns & Cautions
[Worries, risks, or unintended consequences participants flagged]

## Ideas & Solutions
[Creative suggestions or approaches participants proposed]

## Questions Participants Raised
[Things community wants to know or see addressed]

## Commitments & Next Steps

**What We Committed To:**
- [Commitment made to participants]
- [Commitment made to participants]

**How Participants Will Stay Involved:**
- [Ongoing engagement plan]
- [Feedback loop mechanisms]

**Follow-Up:**
- When: [Timeline for next touchpoint]
- What: [What we'll share back]

## Internal Reflections
[What this input means for program design, partnerships, or strategic direction]

**Key Takeaways:**
- [Learning 1]
- [Learning 2]

**Changes to Consider:**
- [Adaptation based on input]

**Questions for Our Team:**
- [Internal discussion needed]
```

**Format Notes:**
- Center community voice, not organizational perspective
- Use direct quotes to preserve authenticity
- Be explicit about commitments made
- Acknowledge power dynamics in facilitation
- Track how input actually influences decisions
- Maintain confidentiality and respect anonymity when needed
- Focus on what participants taught you, not what you taught them

---

## Multi-Stakeholder Coordination Meeting Format

**Use for:** Coalition meetings, cross-sector coordination, and systems change initiatives involving multiple organizations.

```
# [Coalition/Initiative Name] - Coordination Meeting

**Date:** [Date]
**Attendees:**

**Organizations Represented:**
- [Org 1]: [Names and roles]
- [Org 2]: [Names and roles]
- [Org 3]: [Names and roles]

## Meeting Focus
[Primary purpose and desired outcomes for this coordination session]

## Organizational Updates

**[Organization 1]:**
- Progress update: [What they've accomplished]
- Current focus: [What they're working on]
- Needs/Asks: [Support or coordination needed from group]

**[Organization 2]:**
[Repeat structure]

## Alignment & Coordination

**Shared Goals Progress:**
- [Collective goal] - Status: [Progress and contributors]
- [Collective goal] - Status: [Progress and contributors]

**Collaboration Opportunities:**
- [Where organizations can work together]
- [Resource sharing or joint efforts]

**Gaps & Overlap:**
- [Unmet needs in the ecosystem]
- [Duplicated efforts to streamline]

## Systems-Level Insights
[What this group is learning about the broader challenge or opportunity]

**Emerging Patterns:**
- [Trend or dynamic being observed across organizations]

**Barriers:**
- [Systemic obstacles requiring collective action]

## Decisions & Agreements
- [Decision] - Context: [Why and who it affects]
- [Decision] - Context: [Why and who it affects]

*If no formal decisions: "Continued coordination and information sharing; formal decisions will occur through [process]."*

## Commitments & Coordination

**[Organization 1] Commitments:**
- [What] - By when: [Date] - Impact on: [Who/what depends on this]

**[Organization 2] Commitments:**
[Repeat structure]

**Joint Actions:**
- [Coordinated effort] - Leads: [Organizations] - Timeline: [When]

## Communication & Next Meeting

**Between Now & Next Meeting:**
- Communication method: [Email, Slack, monthly calls, etc.]
- Key updates to share: [What to communicate]

**Next Meeting:**
- Date: [When or frequency]
- Focus: [Primary agenda items]
- Decisions needed: [What the group needs to decide]
```

**Format Notes:**
- Respect organizational autonomy while building collective power
- Track interdependencies clearly
- Name both alignment and tension honestly
- Focus on systems change, not just organizational updates
- Be explicit about decision-making authority and process
- Balance efficiency with inclusive participation

---

## Quick Sync/Decision Call Format

**Use for:** 15-30 minute rapid calls for quick decisions, check-ins, or unblocking work.

```
# Quick Sync: [Topic/Person]

**Date:** [Date]
**Duration:** [Actual length]
**Attendees:** [Names]

## Purpose
[One sentence: what needed to be decided or unblocked]

## Decision/Outcome
[The actual decision made or resolution reached]

**Rationale:**
[Why this decision makes sense, key factors considered]

**Alternatives Considered:**
[If relevant, what else was discussed]

## Action Items
- **[Person]:** [Action] - Due: [Date]
- **[Person]:** [Action] - Due: [Date]

## Context for Next Time
[Anything to remember or follow up on in future conversations]
```

**Format Notes:**
- Keep it tight, capture only essential information
- Focus on decision and action, not discussion process
- If the call reveals something needs deeper conversation, note that
- Perfect for unblocking, quick clarifications, or go/no-go decisions

---

## Workshop/Training Session Format

**Use for:** Facilitated learning experiences, capacity building, and strategy workshops with clients or partners.

```
# [Workshop Title]

**Date:** [Date]
**Duration:** [Length]
**Facilitators:** [Names]
**Participants:** [Number and description]

## Workshop Design

**Learning Objectives:**
- [What participants should be able to do/know after]
- [What participants should be able to do/know after]

**Session Flow:**
1. [Module/Section] - [Duration]
2. [Module/Section] - [Duration]
3. [Module/Section] - [Duration]

## Key Activities

### Activity 1: [Name]
**Purpose:** [Why this exercise]
**What Happened:** [How participants engaged, what was produced]
**Insights Generated:**
- [Learning or output from this activity]

### Activity 2: [Name]
[Repeat structure]

## Participant Takeaways

**Group Learning:**
- [Key insight or framework the group developed together]
- [Key insight or framework the group developed together]

**Commitments to Apply:**
- [What participants said they'd do with this learning]

**Questions Still Open:**
- [Topics that need more exploration or support]

## Facilitator Observations

**What Worked Well:**
- [Success in design or delivery]

**What to Adjust:**
- [For next time or with this group]

**Follow-Up Needed:**
- [Resources to share, coaching to offer, connections to make]

## Next Steps

**For Participants:**
- [Actions or practice between sessions]
- [Resources provided]

**For Facilitators:**
- [Follow-up support to provide]
- [Design adjustments for next session]

**Next Session:** (if part of series)
- Date: [When]
- Focus: [Topic]
- Prep: [What participants should do beforehand]
```

**Format Notes:**
- Capture learning design, not minute-by-minute play-by-play
- Focus on what participants discovered, not what you taught
- Note engagement quality and group dynamics
- Track commitments participants made to apply learning
- Document insights for improving future sessions

---

## Post-Mortem/Learning Session Format

**Use for:** Reflection after major projects, partnerships, or initiatives to capture learning and improve practice.

```
# [Project/Initiative Name] - Post-Mortem

**Date:** [Date]
**Participants:** [Who contributed to this reflection]
**Project Timeframe:** [When it ran]

## Project Overview
[Brief reminder of what this was, goals, and scope]

## What Worked Well

### Successes
- [What delivered impact or went better than expected]
- [What delivered impact or went better than expected]

### Strengths We Leveraged
- [Team capabilities, partnerships, approaches that proved effective]

## What Didn't Work

### Challenges
- [What was harder than expected or didn't go well]
- [What was harder than expected or didn't go well]

### Missteps
- [Decisions or approaches we'd change]

## Why It Happened

### Root Causes (Not Just Symptoms)
**For Successes:**
- [Why X worked] - Because: [Underlying factor]

**For Challenges:**
- [Why Y was hard] - Because: [Underlying factor]

### External Factors
- [Context, timing, or conditions outside our control]

### Internal Factors
- [Team dynamics, capacity, systems, or decisions within our control]

## What We Learned

### About Our Work
- [Insight about approach, methodology, or service delivery]

### About Partnerships
- [Learning about collaboration, stakeholder engagement, or relationships]

### About Ourselves
- [Team strengths, gaps, working styles, or capacity]

## What We'll Do Differently

### Immediate Changes
- [Adjustments to make right away in ongoing work]

### Strategic Shifts
- [Bigger pivots in approach, positioning, or offerings]

### Experiments to Try
- [New approaches we want to test]

## What We'll Keep Doing
[Practices, approaches, or strengths to maintain and build on]

## Open Questions
[Things we still don't know or need to explore further]

## Application Plan

**Where to Apply These Learnings:**
- [Current project/context where this is relevant]
- [Current project/context where this is relevant]

**Who Needs to Know:**
- [Team members, partners, or clients who should be informed]

**Follow-Up:**
- [When we'll revisit these insights or check progress on changes]
```

**Format Notes:**
- Create space for honest reflection, not just positivity
- Dig into root causes, not just surface symptoms
- Focus on learning, not blame
- Be specific about what will actually change
- Make it actionable, not just retrospective
- Revisit these learnings in future planning

---

## Vianeo Business Model Validation Sprint Format

**Use for:** Business model validation work using the Vianeo methodology, testing assumptions, and developing sustainable revenue models.

```
# [Organization Name] - Vianeo Sprint Session [Number]

**Date:** [Date]
**Sprint Phase:** [Discovery/Testing/Validation/Synthesis]
**Attendees:**
- **360 Team:** [Names]
- **Client Team:** [Names and roles]

## Session Focus
[1-2 sentences on what this session aimed to accomplish in the validation process]

## Critical Assumptions Tested
[Key assumptions explored and what we learned through validation]

### Assumption 1: [Statement]
**Validation Approach:** [How we tested this, interviews/data/analysis used]
**Finding:** [What we learned, whether validated or invalidated]
**Implication:** [What this means for the business model]

### Assumption 2: [Statement]
[Repeat structure]

## Business Model Insights

### Legitimacy (Strategic Alignment)
[Findings about mission fit and stakeholder buy-in]

### Desirability (Market Demand)
[What we learned about customer needs and willingness to engage]

### Feasibility (Technical Implementation)
[Insights about operational capacity and delivery]

### Viability (Financial Sustainability)
[Discoveries about revenue potential and cost structure]

### Acceptability (Organizational Readiness)
[Learning about internal capacity and cultural fit]

## Revenue Model Analysis
[If applicable, specific findings about sustainability and mission alignment]

**Revenue Streams Explored:**
- [Stream] - Validation status: [What we learned]

**Cost Considerations:**
- [Key cost drivers and their implications]

## Pivots or Refinements
[Changes to the model based on what we learned]

**Adjustments Made:**
- [What changed] - Why: [Learning that drove this]

**Opportunities Identified:**
- [New possibility surfaced through testing]

## Customer/Stakeholder Insights
[Key quotes or learnings from interviews or validation activities]

> "[Quote or insight]" - [Source/Context]

## Action Items

**360 Team:**
- [Action] - Owner: [Name] - Due: [Date]

**Client Team:**
- [Action] - Owner: [Name] - Due: [Date]

## Next Sprint Session

**Focus:** [What we'll tackle in next session]
**Validation Activities Needed:** [Interviews, data gathering, analysis required]
**Prep Required:** [Any work client team needs to do beforehand]
```

**Format Notes:**
- Organize by sprint phase and validation focus, not chronological discussion
- Emphasize learning and model evolution over meeting recap
- Track assumption validation rigorously with evidence
- Connect findings to specific business model components
- Show how learnings drive pivots or refinements
- Keep focus on actionable insights for sustainable model design

---

## Innovation Compass Engagement Format

**Use for:** The 3-step Assess/Prioritize/Validate process using the 360 Innovation Compass methodology for portfolio evaluation.

```
# [Organization Name] - Innovation Compass: [Phase] Session

**Date:** [Date]
**Compass Phase:** [Assess/Prioritize/Validate]
**Attendees:**
- **360 Team:** [Names]
- **Client Team:** [Names and roles]

## Session Objectives
[What this session aimed to accomplish within the 30-day Compass process]

## Initiatives Under Review
[List of initiatives discussed with current status in the process]

**Assessed:**
- [Initiative name] - Status: [Where it stands in evaluation]

**Prioritized:**
- [Initiative name] - Ranking: [Portfolio position]

**Validated:**
- [Initiative name] - Stage: [Deep dive progress]

## Key Findings

### Assessment Phase Insights (if Step 1: Assess)
[Findings from GenIP 11-question evaluation]

**Technology Readiness:**
- [Initiative] - Score/Finding: [What GenIP analysis revealed]

**Market Potential:**
- [Initiative] - Score/Finding: [Market opportunity insights]

**IP & Strategic Fit:**
- [Initiative] - Score/Finding: [Intellectual property and alignment findings]

### Prioritization Analysis (if Step 2: Prioritize)
[Portfolio-level insights from comparative ranking]

**Portfolio Positioning:**
- [Where initiatives landed on the priority grid]
- [Top 20% highest-ROI opportunities identified]

**Go/No-Go Signals:**
- [Initiative] - Recommendation: [Invest/Hold/Pass] - Why: [Rationale]

**Comparative Insights:**
- [What emerges when viewing all initiatives side-by-side]

### Validation Progress (if Step 3: Validate)
[Deep dive findings on top-ranked initiatives]

**Business Case Development:**
- [Initiative] - Progress: [What's been built out]

**Implementation Roadmap:**
- [Key milestones and resource requirements defined]

**Board Readiness:**
- [What's ready for presentation, what still needs work]

## Strategic Implications
[How findings connect to broader innovation strategy or organizational goals]

**Implications for Innovation Portfolio:**
- [Strategic insight for overall portfolio management]

**Resource Allocation Recommendations:**
- [Where to invest based on Compass findings]

## Decisions Made
- [Decision with supporting data from Compass process]
- [Decision with supporting data from Compass process]

*If no firm decisions: "Continued portfolio analysis in [Assess/Prioritize/Validate] phase, decisions expected [timeframe]."*

## Action Items

**360 Team:**
- [Action] - Phase: [Which Compass step] - Due: [Date]

**Client Team:**
- [Action] - Phase: [Which Compass step] - Due: [Date]

## Progress in 30-Day Timeline
[Where we are in the overall Compass process]

**Completed:**
- [Days 1-10: Assess] - [Status]
- [Days 11-14: Prioritize] - [Status]
- [Weeks 3-5: Validate] - [Status]

**Upcoming:**
- [Next phase or milestone]
- [Board presentation readiness timeline]

## Next Session

**Phase:** [Assess/Prioritize/Validate]
**Focus:** [Specific initiatives or analysis areas to cover]
**Timeline:** [When + what needs to happen before then]
**Required Inputs:** [GenIP assessments, stakeholder input, validation data needed]
```

**Format Notes:**
- Always reference which Compass phase (Assess/Prioritize/Validate) you're in
- Connect individual initiative findings to portfolio-level strategy
- Track movement through the structured 30-day process
- Be explicit about decision points and board presentation readiness
- Show how objective GenIP data drives prioritization recommendations
- Emphasize strategic implications beyond individual projects
- Keep focus on delivering board-ready decisions with clear rationale

---

## Investor Meeting Format

**Use for:** Conversations with impact investors, venture capital, equity/debt partners, and investment committees.

```
# [Investor/Fund Name] Meeting Notes

**Date:** [Date]
**Meeting Type:** [Initial Pitch/Due Diligence/Term Discussion/Follow-up]
**Investment Stage:** [Exploration/Active Negotiation/Due Diligence/Closing]
**Attendees:**
- **[Your Organization]:** [Names and roles]
- **[Investor Side]:** [Names and titles]

## Meeting Context
[Brief setup: stage of relationship, what prompted this meeting, investment vehicle being discussed]

## Investment Opportunity Overview
[If initial pitch, high-level summary of what you're raising and why]

**Capital Sought:** [Amount and structure type]
**Use of Funds:** [How capital will be deployed]
**Stage:** [Seed/Series A/Growth/etc.]

## Key Discussion Points

### Investment Thesis Alignment
[How the opportunity aligns with their investment criteria, impact goals, or portfolio strategy]

**Their Investment Focus:**
- [What they typically invest in]
- [Why this fits or connects to their thesis]

**Impact Alignment:**
- [Social/environmental impact thesis match]
- [Theory of change compatibility]

### Deal Structure Explored
[Type of capital discussed and preliminary terms]

**Instrument Type:** [Equity/Convertible Note/SAFE/Debt/Revenue-Based Financing/Other]

**Key Terms Discussed:**
- Valuation: [If discussed]
- Investment amount: [Range or specific]
- Timeline: [Investment and deployment]
- Special conditions: [Milestones, board seats, reporting, etc.]

### Financial Performance & Projections
[Discussion of business model, unit economics, and growth trajectory]

**Metrics Reviewed:**
- [Key metric] - [Current performance]
- [Key metric] - [Projected trajectory]

**Unit Economics:**
- [Cost to acquire, lifetime value, or other key ratios discussed]

### Due Diligence Requirements
[Information they need to complete evaluation]

**Documentation Requested:**
- [Financial statements, cap table, etc.]
- [Impact data, customer validation, etc.]

**Process Expectations:**
- Timeline: [How long due diligence will take]
- Team involved: [Who they need to meet]
- Site visits: [If applicable]

## Investor Questions & Our Responses
[Critical questions they asked and how we addressed them]

1. **Q:** [Question about market/competition/model/team]
   **A:** [Response given]
   **Their Reaction:** [How they received it]

2. **Q:** [Question]
   **A:** [Response]
   **Their Reaction:** [Reception]

## Concerns or Red Flags Raised
[Issues they flagged that need addressing]

- [Concern] - Severity: [High/Medium/Low] - How we'll address: [Plan]
- [Concern] - Severity: [High/Medium/Low] - How we'll address: [Plan]

## Investor Feedback & Signals

**Level of Interest:** [Strong/Moderate/Exploratory/Declining]

**Indicators:**
- [Verbal commitments or hesitations]
- [Body language or engagement quality]
- [Next steps they proposed or timeline urgency]

**Timeline Signals:**
- [When they indicated decision or next conversation]
- [Urgency level based on their other commitments]

## Outstanding Information Needed

**They Need from Us:**
- [Item] - Due: [Date] - Owner: [Name] - Priority: [High/Medium/Low]

**We Need from Them:**
- [Term sheet/Preliminary indication/Investment committee timing]
- Expected: [When we should receive it]

## Competitive Dynamics
[Other investors in play or timeline pressures]

- [Other fund/investor] - Status: [Where they are in process]
- [Other fund/investor] - Status: [Where they are in process]

## Next Steps

**Immediate (Next 2 Weeks):**
- [Specific action items with clear owners and dates]

**Near-Term (This Quarter):**
- [Due diligence milestones, decision points, committee presentations]

**Deal Timeline:**
- Expected decision: [When they'll give go/no-go]
- Due diligence period: [How long]
- Anticipated close: [If progressing to term sheet]

## Internal Strategic Notes
[Confidential team assessment and decision factors]

**Fit Assessment:**
- Strategic value: [Beyond capital, what they bring]
- Mission alignment: [How well values match]
- Terms attractiveness: [Initial read on deal structure]

**Our Position:**
- Interest level: [How much we want this investor]
- Alternatives: [Other options and how they compare]
- Negotiation leverage: [What strengthens our position]

**Decision Criteria:**
- Deal breakers: [What would make this a no]
- Must-haves: [What we need in term sheet]
- Nice-to-haves: [Negotiable elements]
```

**Format Notes:**
- Track investment stage clearly (exploration vs. active term discussion)
- Document terms and structures precisely for comparing offers
- Note both explicit statements and implicit interest signals
- Capture concerns immediately so they can be addressed
- Keep strategic assessment separate in internal notes section
- Be rigorous about follow-up timelines and information requests
- Track competitive dynamics without oversharing with investors
- Distinguish between social impact metrics and financial metrics clearly
- Document any verbal commitments or handshake agreements
- Note cultural fit and partnership quality beyond just terms

---

## Format Selection Guide

### Quick Decision Tree

**Is this a first meeting to scope new work?**
→ Use Discovery/Intake Format

**Is this about raising capital?**
- Grant-based or philanthropic → Funder/Donor Format
- Equity, debt, or impact investment → Investor Format

**Is this client delivery work?**
- General consulting/project work → Client Sprint Session Format
- Business model validation specifically → Vianeo Sprint Format
- Innovation portfolio evaluation → Innovation Compass Format

**Is this about partnerships or strategy?**
- One-on-one strategic partnership → Partner Strategy Format
- Multiple organizations coordinating → Multi-Stakeholder Coordination Format

**Is this organizational governance?**
- Formal board or governance → Board/Governance Format
- Internal team operations → Internal Team Format

**Is this community engagement or learning?**
- Community stakeholder input → Community Stakeholder Format
- Training or workshop delivery → Workshop/Training Format
- Project reflection → Post-Mortem/Learning Format

**Is this just a quick decision?**
→ Use Quick Sync/Decision Call Format

### Format Categories Summary

**CLIENT WORK:**
- Sprint Sessions: Recurring structured consulting
- Discovery/Intake: First meeting needs assessment
- Vianeo Sprints: Business model validation methodology

**STRATEGIC PARTNERSHIPS:**
- Partner Strategy: Two-party strategic collaboration
- Multi-Stakeholder: Coalition/systems change coordination

**GOVERNANCE & STRUCTURE:**
- Board/Governance: Formal organizational decisions
- Internal Team: Operational team coordination

**CAPITAL & RESOURCES:**
- Funder/Donor: Grant-based philanthropic capital
- Investor: Equity/debt investment capital

**COMMUNITY & LEARNING:**
- Community Stakeholder: Lived experience input
- Workshop/Training: Facilitated capacity building
- Post-Mortem: Reflection and continuous improvement

**INNOVATION PORTFOLIO:**
- Innovation Compass: 3-step Assess/Prioritize/Validate process

**OPERATIONAL:**
- Quick Sync: Rapid 15-30 minute decisions

### When You're Uncertain

**Multiple formats could work?**
- Prioritize by primary purpose (what's the main point of the meeting?)
- Consider the deliverables needed (what does success look like?)
- Think about formality level (casual sync vs. formal documentation needs)

**Meeting combines multiple types?**
- Choose the dominant format
- Note in the meeting notes that it covered multiple areas
- You can borrow elements from secondary formats as needed

**Highly specialized or unique meeting?**
- Start with the closest format
- Adapt sections to fit the specific context
- Document what you adjusted for future similar meetings
