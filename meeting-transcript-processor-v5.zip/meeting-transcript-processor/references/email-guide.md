# Email Guide Reference

This document provides detailed guidance for drafting follow-up emails after meetings.

## Contents
- Tone Selection Framework
- Standard Email Structure
- Cultural Context Guidelines
- Email Rules & Principles

---

## Tone Selection Framework

Auto-detect appropriate tone based on context clues in the transcript.

### Brazilian Partners
**Characteristics:**
- Warm, relationship-oriented
- Slightly more formal than US style
- Value personal connection and trust-building
- Often prefer longer relationship development before contracts

**Indicators in transcript:**
- Portuguese language used
- References to Brazilian locations/context
- Emphasis on relationship aspects
- More formal titles used

**Email approach:**
- Open with warmer greeting
- Include brief relationship-building element
- Use full formal signature
- Consider offering Portuguese version

**Example opening:**
"Hi [Name], it was great to connect with you yesterday about [topic]. Your perspective on [specific point] really resonated with our thinking about [connection to their context]."

---

### US Partners
**Characteristics:**
- Direct, action-focused
- Efficiency-oriented
- Value quick decision-making
- Comfortable with informal tone once relationship established

**Indicators in transcript:**
- Focus on timelines and deliverables
- Quick-moving conversation
- Task/outcome orientation
- Less emphasis on relationship preliminaries

**Email approach:**
- Get to the point quickly
- Lead with actionable takeaways
- Conversational but professional
- Clear next steps

**Example opening:**
"Hi [Name], thanks for the productive conversation about [topic]. Three quick takeaways:"

---

### Asian Partners
**Characteristics:**
- Formal, hierarchy-conscious
- Respect for seniority and organizational position
- Indirect communication style
- Consensus-oriented decision making

**Indicators in transcript:**
- Formal titles and respectful language
- References to team/organizational structure
- Less direct disagreement or challenge
- Emphasis on group harmony

**Email approach:**
- Use appropriate formal titles
- Show respect for organizational hierarchy
- Acknowledge broader team/organizational context
- Soften direct requests with appropriate framing
- Full formal signature

**Example opening:**
"Dear [Title] [Last Name], thank you for taking the time to meet with us regarding [topic]. We deeply appreciate [Company]'s thoughtful approach to [subject]."

---

### Established Relationships
**Characteristics:**
- History of successful collaboration
- Shared context and understanding
- Comfortable with shorthand and inside references
- Trust already built

**Indicators in transcript:**
- References to past projects/interactions
- Comfortable banter or jokes
- Inside references or shared language
- Less need for formality or explanation

**Email approach:**
- First name basis
- Conversational tone
- Can reference shared history
- Less formal structure if appropriate
- Simple sign-off (just "Chandler" or "Thanks, Chandler")

**Example opening:**
"Hi [First Name], great to catch up on [topic]. Based on our conversation, here's what we're thinking:"

---

### New Relationships
**Characteristics:**
- Still building trust and understanding
- Need to establish credibility
- May be evaluating fit and capability
- Less shared context

**Indicators in transcript:**
- Introductory elements
- More formal language
- Explaining background/context
- Exploring mutual fit

**Email approach:**
- Professional, respectful tone
- Clear, organized structure
- Include relevant context/credentials if appropriate
- Full signature with contact details
- Err on side of formality

**Example opening:**
"Hi [Name], thank you for meeting with me to discuss [topic]. I wanted to follow up on our conversation about [specific area]."

---

## Standard Email Structure

### Subject Line
**Format:** Specific, clear, actionable

**Good examples:**
- "Next steps: [Project] partnership discussion"
- "Follow-up: Q4 planning session with [Company]"
- "Action items from today's [Topic] meeting"

**Avoid:**
- Generic: "Meeting follow-up"
- Vague: "Thanks for chatting"
- Overly long: "Comprehensive summary of everything we discussed in our meeting about the project including all decisions made and action items identified"

### Email Body Structure

```
Subject: [Specific, clear subject line]

Hi [First Name or appropriate form],

[One sentence thanking them or acknowledging the conversation]

[2-3 sentences covering key takeaways or main point]

**Next steps:**
- [Chandler's action with timeline]
- [Their action with timeline]
- [Coordination point]

[One forward-looking sentence]

[Appropriate sign-off]
Chandler

[Include full signature block for new relationships or formal contexts]
```

### Opening Sentence
**Purpose:** Acknowledge the conversation and set tone

**Options:**
- Thanks + topic: "Thanks for the productive conversation about [topic]."
- Value statement: "I really appreciated your insights on [specific point]."
- Recap: "Following up on our discussion about [topic]."
- Relationship: "It was great to connect with you about [topic]."

### Body (2-3 sentences)
**Purpose:** Capture key takeaways or main point

**Structure:**
- What was discussed/decided
- Why it matters (briefly)
- Connection to next steps

**Keep it concise:**
- Each sentence should add value
- Avoid rehashing entire conversation
- Focus on forward momentum

### Next Steps Section
**Purpose:** Crystal clear on who does what by when

**Format:**
```
**Next steps:**
- Chandler: [Specific action] by [date/timeframe]
- [Partner]: [Specific action] by [date/timeframe]
- Both: [Coordination item] - [when/how]
```

**Guidelines:**
- Be specific about actions
- Include realistic timelines
- Make it easy for them to see their commitments
- If no timeline mentioned, use "by [specific date]" or "in the next week" rather than vague "soon"

### Closing Sentence
**Purpose:** Forward-looking, maintains momentum

**Options:**
- Next interaction: "Looking forward to connecting again on [date/timeframe]."
- Enthusiasm: "Excited to move this forward together."
- Openness: "Let me know if you have any questions in the meantime."
- Milestone: "Looking forward to [next milestone/event]."

### Sign-Off Selection

**Established relationships:**
- "Thanks, Chandler"
- "Best, Chandler"
- Just "Chandler"

**Professional/New relationships:**
- "Best regards, Chandler"
- "Sincerely, Chandler"
- "Warm regards, Chandler" (if culturally appropriate)

**For Brazilian partners:**
- Consider "Abraços, Chandler" if relationship is warm
- "Atenciosamente, Chandler" for more formal

---

## Email Rules (Critical)

### 1. Never Use Em Dashes
**Wrong:** "The project timeline — which we discussed in detail — needs adjustment"
**Right:** "The project timeline (which we discussed in detail) needs adjustment"
**Right:** "The project timeline, which we discussed in detail, needs adjustment"

### 2. Keep Under 200 Words
Unless complex technical content requires more detail, aim for brevity.

**Why:** Time is precious. Respect their inbox.

### 3. Portuguese Version Offer
For Brazilian partners, when appropriate:
"*(Portuguese version available if preferred)*"

Include this at the bottom if:
- It's a new relationship
- The conversation was partly in Portuguese
- There's complex technical or legal content
- They've previously indicated preference

### 4. Match Relationship Warmth
Pay attention to how they communicated in the meeting:
- Formal and professional → Mirror that
- Warm and personal → Match the warmth
- Task-focused and efficient → Keep it tight

### 5. No Fabrication
Only include information actually discussed in the meeting. If uncertain about a detail, either:
- Omit it
- Flag with "[To confirm: ...]"
- Reference it as a question: "You mentioned possibly [X], let me know if I have that right."

---

## Cultural Context Guidelines

### Working Across Cultures

**General principle:** Adapt while staying authentic. Don't become someone you're not, but adjust communication style to show cultural awareness and respect.

### Time Orientation
**US/North American:** Tends toward punctuality, deadlines, efficiency
**Latin American:** More flexible with time, relationship takes priority
**Asian:** Punctuality highly valued, long-term relationship focus

**Application:** Be clear about timeline expectations while allowing for different cultural norms around urgency.

### Communication Directness
**US/German/Dutch:** Direct, explicit communication valued
**Brazilian/Asian/Southern European:** More indirect, context-dependent
**British:** Polite indirectness as social lubricant

**Application:** For more indirect cultures, soften requests and frame disagreements carefully.

### Hierarchy & Formality
**US/Australian:** Relatively flat, first names common
**Latin American:** Respect for hierarchy, but warmth across levels
**Asian/European:** Stronger hierarchy, formal titles important

**Application:** Use appropriate titles and show respect for organizational structure in more hierarchical cultures.

---

## Example Emails

### Example 1: US Partner, Established Relationship
```
Subject: Next steps: Q1 partnership expansion

Hi Sarah,

Great catching up yesterday on the Q1 expansion plans. Your point about focusing on the enterprise segment first makes a lot of sense given the resource constraints we discussed.

**Next steps:**
- Chandler: Draft proposal outline by Friday, Dec 1
- Sarah: Share Q4 performance data by Wednesday, Nov 29  
- Both: Sync call week of Dec 4 to finalize approach

Looking forward to moving this forward together.

Thanks,
Chandler
```

### Example 2: Brazilian Partner, New Relationship
```
Subject: Follow-up: Partnership discussion with 360 Edutech

Hi Dr. Silva,

Thank you for taking the time to meet with me today about potential collaboration between our organizations. I was particularly encouraged by your vision for expanding educational access in the northeast region.

Based on our conversation, I understand you're interested in exploring how our AI-powered learning platforms might complement your existing programs. I also appreciated your emphasis on ensuring any solution aligns with Brazilian educational standards and cultural context.

**Next steps:**
- Chandler: Send detailed case studies from similar partnerships by November 30
- Dr. Silva: Share information about current program structure and goals
- Both: Reconvene in mid-December to discuss potential pilot program

I'm excited about the possibilities here and look forward to continuing our conversation.

Warm regards,
Chandler Lewis
Founder & CEO, 360 Edutech
chandler@360edutech.com

*(Portuguese version available if preferred)*
```

### Example 3: Asian Partner, Formal Context
```
Subject: Follow-up: Strategic partnership discussion

Dear Mr. Tanaka,

Thank you very much for meeting with our team to discuss potential collaboration between our organizations. We were honored by the time and thoughtful consideration your team provided.

We understand that NTK Education is evaluating several partnership opportunities and appreciate being included in your consideration. Based on our discussion, we recognize that alignment with your organization's mission and values is paramount, and we share your commitment to excellence in educational outcomes.

**Next steps:**
- 360 Edutech team: Prepare detailed proposal addressing the key requirements discussed, to be submitted by December 15
- NTK Education team: Share feedback on preliminary approach by December 1
- Both teams: Schedule follow-up meeting in January to review proposal

We deeply appreciate NTK Education's leadership in the education sector and look forward to the possibility of contributing to your important work.

Respectfully,

Chandler Lewis
Founder & CEO
360 Edutech
chandler@360edutech.com
```

---

## Quality Checklist for Emails

Before sending, verify:
- [ ] No em dashes anywhere
- [ ] Under 200 words (unless complexity requires more)
- [ ] Tone matches relationship and culture
- [ ] Subject line is specific and clear
- [ ] Action items have owners and timelines
- [ ] No fabricated information
- [ ] Appropriate sign-off for context
- [ ] Portuguese offer included if Brazilian partner and appropriate
- [ ] Forward-looking closing sentence
- [ ] Easy to scan and act on
