---
name: meeting-transcript-processor
description: Process meeting transcripts into professional notes, follow-up emails, action items, and next-meeting context. Use when user provides a transcript or meeting notes to process.
---

# Meeting Transcript Processor

## Purpose
Transform meeting transcripts into complete deliverable packages matching Chandler's workflow and communication style across all types of meetings in his work.

## When to Use
- User uploads or pastes a meeting transcript
- User says "process these notes" or "generate follow-up from this meeting"
- User mentions needing meeting documentation or follow-up materials
- User asks for help documenting any type of strategic conversation

## Quick Start

**Every processing run produces ALL four outputs:**
1. Professional meeting notes (format varies by meeting type)
2. Follow-up email draft (tone varies by relationship)
3. Asana task list (with project recommendations)
4. Next meeting context brief (what to remember for next time)

## Workflow

### Step 1: Identify Meeting Type

Read the transcript carefully and determine which format best fits. Refer to the comprehensive selection guide in the meeting formats document.

**Client Work (3 formats):**
- **Client Sprint Sessions:** Recurring structured consulting or Vianeo engagements
- **Discovery/Intake Sessions:** First meetings for needs assessment and fit evaluation
- **Vianeo Business Model Validation Sprints:** Assumption testing and business model work

**Strategic Partnerships (2 formats):**
- **Partner Strategy Meetings:** Two-party strategic collaboration discussions
- **Multi-Stakeholder Coordination:** Coalition work and systems change coordination

**Governance & Structure (2 formats):**
- **Board/Governance Meetings:** Formal organizational decision-making
- **Internal Team Meetings:** Operational team coordination and syncs

**Capital & Resources (2 formats):**
- **Funder/Donor Meetings:** Grant-based philanthropic partnerships
- **Investor Meetings:** Equity, debt, or impact investment discussions

**Community & Learning (3 formats):**
- **Community Stakeholder Sessions:** Centering lived experience and community voice
- **Workshop/Training Sessions:** Facilitated learning and capacity building
- **Post-Mortem/Learning Sessions:** Project reflection and continuous improvement

**Innovation Portfolio (1 format):**
- **Innovation Compass Engagements:** 3-step Assess/Prioritize/Validate portfolio work

**Operational (1 format):**
- **Quick Sync/Decision Calls:** Rapid 15-30 minute decision-making

**Quick Decision Tree:**
- First meeting to scope work? → Discovery/Intake
- Raising capital? → Funder/Donor (grants) or Investor (equity/debt)
- Client delivery? → Sprint Session, Vianeo Sprint, or Innovation Compass
- Partnership/strategy? → Partner Strategy or Multi-Stakeholder
- Governance? → Board/Governance or Internal Team
- Community/learning? → Community Stakeholder, Workshop, or Post-Mortem
- Quick decision? → Quick Sync

### Step 2: Generate Meeting Notes

Use the appropriate format from [references/meeting-formats.md](references/meeting-formats.md).

**Universal Principles (Apply to All Formats):**
- Professional, factual tone
- Organized by theme/logic, not strict chronology
- Use direct quotes only when impactful
- Include enough detail for someone who wasn't there
- Never fabricate information not in the transcript
- Flag uncertainties with [NEEDS CLARIFICATION]
- No made-up dates (use "TBD" if not mentioned)

**Format-Specific Considerations:**

**For Community Stakeholder Sessions:**
- Center community voice over organizational perspective
- Preserve authenticity in direct quotes
- Be explicit about commitments made
- Acknowledge power dynamics
- Maintain confidentiality and anonymity appropriately

**For Investment/Funder Meetings:**
- Document terms and structures precisely
- Track both explicit statements and implicit signals
- Keep strategic assessments in internal notes section
- Note competitive dynamics without oversharing

**For Validation Sprints (Vianeo/Innovation Compass):**
- Organize by validation phase/framework, not discussion order
- Track assumptions tested with evidence
- Show how learnings drive model refinements
- Connect to broader portfolio or sustainability strategy

**For Multi-Stakeholder Coordination:**
- Respect organizational autonomy while building collective power
- Track interdependencies clearly
- Name both alignment and tension honestly
- Be explicit about decision-making authority

### Step 3: Draft Follow-Up Email

Consult [references/email-guide.md](references/email-guide.md) for:
- Tone selection based on relationship type
- Standard structure and rules
- Cultural context considerations

**Email Tone by Meeting Type:**
- Client work → Professional, progress-focused
- Partner strategy → Warm, strategic, relationship-building
- Funder/donor → Mission-aligned, accountable
- Investor → Confident, data-driven, clear on next steps
- Community stakeholder → Respectful, honoring input received
- Board/governance → Formal, action-oriented
- Internal team → Direct, operational
- Workshop/training → Encouraging, resourceful
- Post-mortem → Reflective, forward-looking

**Special Considerations:**
- Discovery/Intake: Set clear expectations for next steps and decision timeline
- Multi-stakeholder: Ensure all organizations feel represented
- Community sessions: Reiterate commitments made during session
- Investor meetings: Include precise follow-up on information requests

### Step 4: Create Asana Task List

Refer to [references/project-logic.md](references/project-logic.md) for project assignment rules.

Format:
```
**Recommended Asana Project:** [Project name based on logic]

**Tasks to Create:**

Chandler Lewis:
- Task: [Description] | Due: [Date or TBD] | Notes: [Context]

[Partner/Client Name]:
- Task: [Description] | Due: [Date or TBD] | Notes: [Context]
```

**Project Selection by Meeting Type:**
- Client sprint sessions → Use client-specific project
- Vianeo sprints → "Vianeo - [Client Name]" project
- Innovation Compass → "Innovation Compass - [Client Name]" project
- Partner strategy → Partnership-specific or business development project
- Funder/donor → Grants management or partnership project
- Investor meetings → Fundraising pipeline project
- Community stakeholder → Program-specific community engagement project
- Internal team → Team/department operational project

**Task Naming Conventions:**
- Be specific about deliverable, not just "follow up"
- Include enough context for task to be understood standalone
- Flag dependencies or blockers in notes field
- For multi-stakeholder work, note which organization is responsible

### Step 5: Create Next Meeting Brief

```
## Context for Next Meeting with [Name/Company]

**Where We Left Off:**
[1-2 sentence summary]

**Open Questions to Address:**
- [Question 1]
- [Question 2]

**What to Watch For:**
[Concerns, sensitivities, blockers, decision points]

**Relationship Notes:**
[Communication style, preferences, cultural context]
```

**Enhanced Context for Specific Meeting Types:**

**Discovery/Intake Sessions:**
Add section:
**Fit Assessment:**
- Alignment: [Why this could be good match]
- Concerns: [Potential issues to monitor]
- Decision timeline: [When both parties will decide]

**Investor Meetings:**
Add sections:
**Deal Status:**
- Stage: [Exploration/Due Diligence/Term Discussion]
- Interest level: [Their signals]
- Competitive position: [Other investors in play]

**Negotiation Position:**
- Our leverage: [What strengthens our hand]
- Their concerns: [What we need to address]
- Must-haves vs. nice-to-haves: [Our priorities]

**Community Stakeholder Sessions:**
Add section:
**Application of Input:**
- How this input is being used
- Changes being made based on feedback
- Loop-back plan for sharing impact

**Validation Sprints:**
Add section:
**Model Evolution:**
- Assumptions validated/invalidated
- Pivots made based on learning
- Next validation focus areas

**Multi-Stakeholder Coordination:**
Add section:
**Coalition Dynamics:**
- Organizational relationships
- Decision-making process
- Areas of tension or misalignment to navigate

## Style Guidelines Reference

For detailed guidance on Chandler's voice and communication principles, see [references/style-guide.md](references/style-guide.md).

**Critical Rules (Apply to ALL Meeting Types):**
- **Never use em dashes** (use commas, periods, or parentheses)
- **Never fabricate information** not in the transcript
- **Flag uncertainties** with [NEEDS CLARIFICATION]
- **No made-up dates** (use "TBD" if not mentioned)
- **Match relationship tone** from the conversation

**Additional Guidelines by Format:**

**High Formality (Board/Governance, Investor):**
- Use more structured language
- Document decisions precisely
- Track attendance/participation explicitly

**Community-Centered (Community Stakeholder):**
- Preserve authentic voice through direct quotes
- Avoid organizational jargon
- Center participant contributions, not facilitator actions

**Learning-Focused (Workshop, Post-Mortem):**
- Emphasize insights and takeaways
- Be honest about what didn't work
- Make learning actionable

**Strategic (Partner, Multi-Stakeholder, Innovation Compass):**
- Connect to broader ecosystem or systems context
- Show both current state and future trajectory
- Name power dynamics and alignment explicitly

## Language Handling

**Mixed Language Transcripts:**
- Meeting notes: Keep original language for quotes, translate key points to English
- Follow-up emails: Draft in English, note if Portuguese version should be offered
- Flag any sections where translation uncertainty might affect meaning

**Cultural Considerations:**
- Latin America (especially Brazil): More relationship-building, indirect communication
- Note communication style preferences for follow-up
- Flag if cultural context affects interpretation of discussion

## Quality Checklist

Before delivering, verify:

**Universal Requirements (All Meeting Types):**
- [ ] All 4 outputs included (notes, email, tasks, next meeting brief)
- [ ] No em dashes anywhere
- [ ] Dates are real or marked TBD
- [ ] Action items have clear owners
- [ ] Email tone matches relationship context
- [ ] No information fabricated
- [ ] Asana project suggestion makes sense

**Format-Specific Checks:**

**Client/Consulting Work:**
- [ ] Themes/insights captured (not just chronology)
- [ ] Information gaps explicitly noted
- [ ] Next session focus identified

**Validation Sprints (Vianeo/Innovation Compass):**
- [ ] Assumptions and validation status tracked
- [ ] Business model components addressed
- [ ] Pivots or refinements documented
- [ ] Phase/stage clearly identified

**Capital Meetings (Investor/Funder):**
- [ ] Terms documented precisely
- [ ] Due diligence requirements captured
- [ ] Timeline and decision process noted
- [ ] Strategic assessment in internal notes section

**Community & Stakeholder Engagement:**
- [ ] Community voice centered
- [ ] Commitments to participants explicit
- [ ] Power dynamics acknowledged
- [ ] Follow-up plan clear

**Multi-Stakeholder Coordination:**
- [ ] All organizations represented fairly
- [ ] Interdependencies mapped
- [ ] Decision-making authority clarified
- [ ] Joint actions distinguished from org-specific

**Governance:**
- [ ] Attendance tracked
- [ ] Formal decisions documented
- [ ] Resolutions clear and actionable
- [ ] Action items consolidated in register

## Troubleshooting

**Can't determine meeting type?**
1. Look at attendees (internal vs. external, who has power/authority)
2. Identify primary purpose (decision-making, learning, coordination, validation)
3. Check for methodological clues (Vianeo framework, Innovation Compass phases)
4. Default to closest format and note uncertainty to user

**Meeting combines multiple types?**
- Use dominant format as base structure
- Borrow relevant sections from secondary formats
- Note in output which format was used and why

**Transcript is unclear or incomplete?**
- Produce outputs based on available information
- Flag gaps prominently with [NEEDS CLARIFICATION]
- Note in follow-up email that clarification is needed
- Suggest what questions to ask to fill gaps

**Cultural context is ambiguous?**
- Default to professional but warm tone
- Avoid assumptions about hierarchy or communication style
- Note in next meeting brief that cultural context should be confirmed

**Very short/quick meeting?**
- Quick Sync format still generates all 5 outputs
- Keep notes ultra-concise
- Focus tracker on the decision made
- Next meeting brief can be brief but should capture key context

## Version History

**v3.0.0 (Current):**
- Expanded from 4 to 14 meeting format types
- Added Innovation Compass engagement format
- Added Vianeo business model validation sprint format
- Added investor meeting format
- Added funder/donor meeting format
- Added discovery/intake session format
- Added community stakeholder session format
- Added multi-stakeholder coordination format
- Added workshop/training session format
- Added post-mortem/learning session format
- Added quick sync/decision call format
- Enhanced format-specific guidance throughout workflow
- Added comprehensive format selection decision tree

**v2.0.0:**
- Restructured around 5-output system
- Added format-specific guidance
- Enhanced style guidelines integration
- Added language handling section

**v1.0.0:**
- Initial release with 4 core formats
- Basic workflow and output structure
