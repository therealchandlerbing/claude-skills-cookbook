---
name: meeting-transcript-processor
description: Process meeting transcripts into professional notes, follow-up emails, action items, and next-meeting context. Use when user provides a transcript or meeting notes to process.
---

# Meeting Transcript Processor

## Purpose
Transform meeting transcripts into multiple deliverables matching Chandler's workflow and communication style across different contexts (client sprints, partner meetings, board sessions, internal check-ins).

## When to Use
- User uploads or pastes a meeting transcript
- User says "process these notes" or "generate follow-up from this meeting"
- User mentions needing meeting documentation or follow-up materials

## Output Package

Every time this Skill runs, produce ALL of the following outputs:

### 1. Professional Meeting Notes

**Format Selection:**
- **Client Sprint Sessions** (Vianeo, consulting engagements): Use detailed sprint format
- **Partner Strategy Meetings**: Use streamlined format
- **Board/Governance Meetings**: Use formal minutes format
- **Internal Team Meetings**: Use action-focused format

**Standard Sprint Session Format:**
```
# [Project Name] - [Session Type] Meeting Notes

**Date:** [Date]
**Duration:** [Length]
**Attendees:**
- **360 Team:** [Names and roles]
- **Client Team:** [Names and roles]

---

## Key Themes Explored
[3-5 main topics with brief context]
- Theme 1: [One sentence]
- Theme 2: [One sentence]

## Critical Questions & Answers
[Most important Q&As from the discussion]
1. **Q:** [Question]
   **A:** [Concise answer]

## Major Insights & Breakthroughs
[Significant discoveries or strategic shifts]
- [Insight 1]
- [Insight 2]

*If none: "No major strategic shifts; session focused on information gathering/validation."*

## Action Items

**360 Team:**
- [Action] - Owner: [Name] - Due: [Date or TBD]

**Client Team:**
- [Action] - Owner: [Name] - Due: [Date or TBD]

## Information Gaps & Next Steps
**Outstanding Information Needed:**
- [Item 1]

**Next Meeting Focus:**
- [Topic areas to prioritize]
- [Required attendees if specific people needed]
```

**Streamlined Partner Meeting Format:**
```
# [Partner/Company Name] Meeting Notes

**Date:** [Date]
**Attendees:** [Names]

## Discussion Summary
[2-3 paragraphs covering main topics]

## Decisions Made
- [Decision 1 with rationale]

## Action Items
- **Chandler:** [items]
- **[Partner Name]:** [items]

## Next Steps
[What happens next, timeline, focus areas]
```

### 2. Follow-Up Email Draft

**Tone Selection:**
Auto-detect based on context clues in transcript:
- **Brazilian partners**: Warm, relationship-oriented, slightly more formal
- **US partners**: Direct, action-focused, efficiency-oriented  
- **Asian partners**: Formal, hierarchy-conscious
- **Established relationships**: Conversational, first-name basis
- **New relationships**: Professional, full signature

**Standard Structure:**
```
Subject: [Specific, clear subject line]

Hi [First Name or appropriate form],

[One sentence thanking them or acknowledging the conversation]

[2-3 sentences covering key takeaways or main point]

**Next steps:**
- [Chandler's action] 
- [Their action]
- [Timeline/coordination point]

[One forward-looking sentence]

[Appropriate sign-off]
Chandler
```

**Rules:**
- Never use em dashes
- Keep under 200 words unless complex technical content
- If Brazilian partner and appropriate, offer: "*(Portuguese version available if preferred)*"
- Match the relationship warmth level from the transcript

### 3. Asana Task List
```
**Recommended Asana Project:** [Suggest based on meeting content]

**Tasks to Create:**

Chandler Lewis:
- Task: [Description] | Due: [Date or TBD] | Notes: [Context]
- Task: [Description] | Due: [Date or TBD] | Notes: [Context]

[Partner/Client Name]:
- Task: [Description] | Due: [Date or TBD] | Notes: [Context]

Team (Eduardo/Felipe/Claude):
- Task: [Description] | Assignee: [Specific person if clear] | Due: [Date or TBD]
```

**Project Assignment Logic:**
- Sprint clients → Their dedicated project (if exists) or "Weekly Meeting Tracker"
- Strategic partners → Partner-specific project or "NWK Global Partnership Development"
- CNEN projects → "CNEN Meeting Hub" or specific project tracker
- Internal → "Weekly Meeting Tracker"
- When uncertain → Flag with "[NEEDS PROJECT ASSIGNMENT]"

### 4. Commitment Tracker
```
## Commitment Tracker

**Commitments by Chandler/360:**
- [What] - To: [Person/Org] - By: [Date/Timeframe]
- [What] - To: [Person/Org] - By: [Date/Timeframe]

**Commitments by [Partner/Client]:**
- [What] - By: [Date/Timeframe]
- [What] - By: [Date/Timeframe]

**Pending from Previous Meetings:**
[If mentioned in transcript, list what's still outstanding]

**Dependencies/Blockers:**
[Anything waiting on external parties or decisions]
```

### 5. Next Meeting Context Brief
```
## Context for Next Meeting with [Name/Company]

**Where We Left Off:**
[1-2 sentence summary of meeting conclusion]

**Open Questions to Address:**
- [Question 1]
- [Question 2]

**What to Watch For:**
[Any concerns, sensitivities, blockers, or decision points mentioned]

**Relationship Notes:**
[Communication style, preferences, cultural context, anything relevant for next interaction]
```

## Language Handling

**Mixed Language Transcripts:**
- Meeting notes: Keep original language for quotes, translate key points to English for clarity
- Follow-up emails: Draft in English, note if Portuguese version should be offered
- Flag any sections where translation uncertainty might affect meaning

## Critical Rules

1. **Never fabricate information** not in the transcript
2. **Flag uncertainties** with [NEEDS CLARIFICATION] 
3. **No made-up dates** - use "TBD" if deadline not mentioned
4. **Match relationship tone** - pay attention to formality level in the conversation
5. **Preserve Chandler's voice**: Grounded, purpose-driven, concise, no unnecessary words
6. **Never use em dashes** - use commas, periods, or parentheses instead
7. **Action-oriented** - focus on what moves things forward
8. **Respect cultural context** - adapt tone appropriately

## Style Guidelines

**Chandler's Communication Principles:**
- Brevity with depth (no fluff, but don't skip substance)
- Purpose-driven (connect to why, not just what)
- Strategic alignment (how does this fit the bigger picture)
- Authentic and relational (professional but human)
- Time is precious (make it easy to act on)

**Meeting Notes:**
- Professional, factual tone
- Organized by theme/logic, not strict chronology
- Use direct quotes only when impactful
- Include enough detail for someone who wasn't there to understand

**Emails:**
- Clear call-to-action
- Easy to scan
- Respectful of recipient's time
- Warm but not overly casual
- Never apologetic unless genuine apology needed

## Example Trigger Phrases

User might say:
- "Process this transcript from my Thinkie meeting"
- "I need meeting notes from today's call with InovaEduK"
- "Generate follow-up materials for the Avatar Partners session"
- "Here are my notes from the board meeting, can you structure them?"

When you see any of these, invoke this Skill.

## Quality Checklist

Before delivering outputs, verify:
- [ ] All 5 outputs are included
- [ ] No em dashes anywhere
- [ ] Dates are real or marked TBD
- [ ] Action items have clear owners
- [ ] Email tone matches relationship context
- [ ] No information fabricated
- [ ] Asana project suggestion makes sense
- [ ] Commitment tracker captures all promises