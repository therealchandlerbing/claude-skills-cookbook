---
name: weekly-tracker-generator
description: Generate weekly status summaries from Asana projects automatically. Use when user asks for weekly tracker, weekly summary, or status update.
---

# Weekly Tracker Auto-Generator

## Purpose
Automatically generate Chandler's weekly status summary by reading Asana projects and compiling them into his standard weekly tracker format. This eliminates the manual work of reviewing projects and writing summaries every week.

## When to Use
- User says "generate my weekly tracker"
- User asks "create weekly summary" or "weekly status update"
- User requests "what got done this week"
- User says "prep my weekly update"
- Any Sunday evening or Monday morning when user wants the weekly summary

## How This Works

You have access to:
1. **Asana workspace** - Read all projects in the 360socialventures.com workspace
2. **Past conversations** - Reference previous weekly trackers for format consistency
3. **Calendar** - Check for completed meetings and upcoming priorities

The primary source is the Asana "Weekly Meeting Tracker" project, but you'll also scan other active projects for additional context.

## Output Format

Generate the weekly tracker in this EXACT format:
```
# Weekly Email Tracker - [Date Range]

🎯 KEY ACCOMPLISHMENTS:
- [Completed action items from "Other Highlights" or similar sections]
- [Major financial/legal actions taken]
- [New opportunities advanced]
- [Key deliverables completed]

💼 ACTIVE WORKSTREAMS

**Action Required:** [X] items pending
- [Brief description of item] - [Status/deadline if relevant]
- [Brief description of item] - [Status/deadline if relevant]

**Financial & Legal:** [X] items in progress
- [Brief description of item] - [Status/deadline if relevant]

**New Inquiries:** [X] opportunities active
- [Brief description of item] - [Who/what/when]

**Active Partnerships:** [X] items in motion
- [Brief description of item] - [Status]

**Clients & Mentees:** [X] engagements progressing
- [Brief description of item] - [Status]

📈 METRICS:
- Total tasks completed: [X]
- New tasks added: [X]
- Active workstream items: [X]
- High-priority meetings scheduled: [X] ([dates])
- Geographic spread: [List regions/countries of active work]

⚠️ ATTENTION NEEDED:
- [Items blocked/waiting on external parties]
- [Urgent follow-ups for next week]
- [Decisions required]
- [Overdue items]

📋 UPCOMING FOCUS:
- [Top 3-5 priorities for next week]
- [Key meetings/deadlines coming up]
- [Strategic initiatives to advance]
```

## Data Collection Process

**Step 1: Connect to Asana workspace**
Use `Asana:asana_list_workspaces` to confirm workspace access, then use workspace gid: 1210382795871981

**Step 2: Read Weekly Meeting Tracker project**
- Use `Asana:asana_typeahead_search` to find "Weekly Meeting Tracker" project
- Get project gid
- Use `Asana:asana_get_project` to get project details
- Use `Asana:asana_get_project_sections` to get all sections
- Use `Asana:asana_get_tasks` to get tasks from each section

**Step 3: Analyze task data**
For each section in the Weekly Meeting Tracker:
- Count tasks by status (complete/incomplete)
- Extract task names and details
- Note any due dates or time-sensitive items
- Identify blockers or dependencies

**Step 4: Scan other active projects for context**
- Use `Asana:asana_get_projects` to list all projects
- Focus on projects with recent activity
- Look for completed tasks in the past week
- Note any new projects or major milestones

**Step 5: Check calendar for meeting data**
- Use `list_gcal_events` to find meetings from the past week
- Count high-priority meetings
- Identify upcoming meetings for next week

**Step 6: Compile into format**
Use all gathered data to populate the template above.

## Section Mapping Logic

The Weekly Meeting Tracker project in Asana has these typical sections. Map them to the output format:

**Asana Section → Output Section:**
- "Other Highlights" → Key Accomplishments
- "Action Required" → Action Required
- "Financial & Legal" → Financial & Legal
- "New Inquiries" → New Inquiries
- "Active Partnerships" → Active Partnerships
- "Clients & Mentees" → Clients & Mentees

**Task Status Interpretation:**
- Completed tasks this week → Key Accomplishments
- Incomplete tasks → Count for each workstream
- Tasks with upcoming due dates → Attention Needed or Upcoming Focus
- Overdue tasks → Attention Needed

## Metrics Calculation

**Total tasks completed:**
Count all tasks marked complete in the past 7 days across all sections

**New tasks added:**
Count tasks created in the past 7 days

**Active workstream items:**
Sum of all incomplete tasks across all sections

**High-priority meetings:**
Count calendar events from past week that had 3+ attendees or were client/partner meetings

**Geographic spread:**
Based on task/project names, identify regions:
- North America (US, Canada)
- Latin America (Brazil specifically)
- Asia-Pacific (China, Australia)
- Europe

## Important Rules

1. **Use actual data** - Every number must come from Asana or calendar, no estimates
2. **Include context** - Don't just list task names, add brief status/context
3. **Flag urgent items** - If something is overdue or blocked, call it out in Attention Needed
4. **Be strategic** - Upcoming Focus should be actionable priorities, not just a task list
5. **Maintain consistency** - Format should match previous weekly trackers exactly
6. **Never use em dashes** - Use commas, periods, or parentheses instead
7. **Geographic context matters** - Always note which regions/countries work spans
8. **Real dates only** - Reference actual meeting dates from calendar

## Handling Edge Cases

**If Weekly Meeting Tracker project not found:**
1. Search for it using typeahead
2. If still not found, ask user to confirm project name
3. Offer to generate from other active projects instead

**If sections don't match expected names:**
1. List found sections
2. Ask user to confirm mapping
3. Proceed with best-guess mapping and note uncertainty

**If no completed tasks found:**
```
🎯 KEY ACCOMPLISHMENTS:
- No completed tasks recorded in Asana this week
- [Still note any meetings held or progress made based on calendar]
```

**If it's early in the week (Monday/Tuesday):**
Note in output: "Note: Generated early in week, may not reflect full week's activity yet."

## Quality Checklist

Before delivering the tracker:
- [ ] Connected to correct Asana workspace
- [ ] Read Weekly Meeting Tracker project
- [ ] Counted all metrics accurately
- [ ] Scanned other projects for additional context
- [ ] Checked calendar for meeting data
- [ ] Flagged time-sensitive or blocked items
- [ ] Suggested strategic priorities for next week
- [ ] Verified geographic spread is accurate
- [ ] Used exact format from template
- [ ] No em dashes anywhere

## Example Trigger Phrases

User might say:
- "Generate my weekly tracker"
- "Create weekly summary for Oct 17"
- "I need the weekly status update"
- "What's my weekly tracker look like?"
- "Prep my weekly update"

When you see any of these patterns, invoke this Skill.

## Output Delivery

After generating the tracker:
1. Display the complete formatted summary
2. Ask if user wants any sections expanded or adjusted
3. Offer to create it as a document if needed
4. Remind user this can be run weekly on demand
